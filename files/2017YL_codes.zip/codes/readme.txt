The codes are tested on MATLAB 2016a in 64-bit Windows 7. The pseudospectral method is programmed based on GPOPS version 5.1.

To get the results, run 'main.m' (for Methods 1 & 2) or 'TrainSchedulingMain.m' (for PM).

%% explanation of folders

..\code\case study 1\									% for case study in Section 4.2 of the paper (classic single-train optimal train control without intermediate constraints)
..\code\case study 1\pseudospectral method\				% Pseudospectral Method (PM)
..\code\case study 1\method 1\original\					% Method 1 without removing any operation 
..\code\case study 1\method 1\with operations removed	% Method 1 with some short-duration operations removed
..\code\case study 1\method 2\							% Method 2

..\code\case study 2\									% for case study in Section 4.3 of the paper (subway line scheduling)
..\code\case study 2\cal energy under fixed schedule\	% calculate the total energy consumption under a fixed schedule (using Method 1)
..\code\case study 2\cal min running time\				% calculate the minimum running time of each interstation journey (using Method 1)
..\code\case study 2\cal optimal schedule\				% calculate the optimal schedule


%% explanation of .m files (for Methods 1 & 2)

main.m									% main function
train_network_yizhuang.m				% description of the Yizhuang Line
energy_consumption_analytic.m			% calculate the total energy consumption of the whole journey
cal_energy.m							% calculate the energy consumption during the max-traction operation on a particular subsection
solve_energy_linear.m					% calculate the energy consumption of the non-constant piece of tractive force, during the max-traction operation, on a particular subsection
nonlcon_braking_curve_analytic.m		% define the nonlinear constraints of the nonlinear programming formulations 
solve_ode_piecewise.m					% solve a second-order ode with piecewise-constant coefficients (two pieces)
solve_ode.m								% solve a second-order ode with constant coefficients
temp_figure.m							% plot train trajectories given train control profiles
temp_dynamics.m							% describe the train dynamics, for plotting train trajectories
