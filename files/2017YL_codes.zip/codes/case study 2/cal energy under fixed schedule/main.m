clear;
clc;

global section_num;
global subsection_num;
global sl;
global gd;
global subsection_length;
global total_running_time;
global current_speed;
global subsection_list;
train_network_yizhuang

subsection_length_max=2000;
subsection_mark=sort(unique([sl_table(:,3);sl_table(end,4); gd_table(:,3);gd_table(end,4);station_location']));
subsection_mark_new=[];
for i=1:length(subsection_mark)-1
    subsection_mark_new=[subsection_mark_new; subsection_mark(i,:)];
    subsection_length_i=subsection_mark(i+1)-subsection_mark(i);
    divide_num=ceil(subsection_length_i/subsection_length_max);
    if divide_num>1
        for k=1:divide_num-1
            subsection_mark_new=[subsection_mark_new; subsection_mark(i,:)+ k*subsection_length_i/divide_num];
        end;
    end;
end;
subsection_mark_new=[subsection_mark_new; subsection_mark(end)];
subsection_mark=subsection_mark_new;

subsection_list=[subsection_mark(1:end-1), subsection_mark(2:end)];
for i=1:size(subsection_list,1)
    subsection_list(i,3)=gd_table(find(subsection_list(i,1)>=gd_table(:,3) & subsection_list(i,1)<=gd_table(:,4) & subsection_list(i,2)>=gd_table(:,3) & subsection_list(i,2)<=gd_table(:,4)),2);
    subsection_list(i,4)=sl_table(find(subsection_list(i,1)>=sl_table(:,3) & subsection_list(i,1)<=sl_table(:,4) & subsection_list(i,2)>=sl_table(:,3) & subsection_list(i,2)<=sl_table(:,4)),2);
end;

subsection_list_whole_line=subsection_list;
section_end=zeros(section_num,1);
for i_section=1:section_num
    section_end(i_section,1)=find(subsection_list_whole_line(:,2)==station_location(i_section+1));
end;
section_start=[1; section_end(1:end-1)+1];

for i_section=1:section_num
    subsection_list=subsection_list_whole_line(section_start(i_section):section_end(i_section),:);
    
    subsection_num=size(subsection_list,1);
    sl=subsection_list(:,4)';
    gd=subsection_list(:,3)';
    subsection_length=[subsection_list(:,2)-subsection_list(:,1)]';
    total_running_time=running_time(1,i_section);
    current_speed = 0;
    min_sub_running_time=subsection_length./sl;
    
    global a_r  b_r  c_r  a_max  a_min;
    a_r=1.0393/10^4;
    b_r=0;
    c_r=0.0142;
    a_max=310/278;
    a_min=260/278;
    
    nvars=7*subsection_num;
    LB=zeros(7*subsection_num,1);
    UB=zeros(7*subsection_num,1);
    for i=1:subsection_num
        UB(7*(i-1)+[1:4])=total_running_time-sum(min_sub_running_time)+min_sub_running_time(i);
        UB(7*(i-1)+[5:6])=sl(i);
        if i~=subsection_num
            UB(7*i)=min(sl(i), sl(i+1));
        else
            UB(7*i)=0;
        end;
    end;
    Aeq=repmat([ones(1,4), zeros(1,3)], 1, subsection_num);
    beq=total_running_time;
    
    trial_num=1;
    energy_consumption=zeros(trial_num,1);
    opt_result=zeros(trial_num, subsection_num*7);
    for xxx=1:trial_num
        xxx;
        x0=zeros(1,nvars);
        x0_t=repelem(total_running_time-sum(min_sub_running_time)+min_sub_running_time,4).*rand(1, 4*subsection_num);
        x0_t=x0_t/sum(x0_t)*total_running_time;
        for i=1:subsection_num
            x0(1,(i-1)*7+[1:4])=x0_t((i-1)*4+[1:4]); % total_running_time/(subsection_num*4);
            x0(1,(i-1)*7+[5:6])=sl(i)*rand(1);
            if i~=subsection_num
                x0(1,(i-1)*7+7)=min(sl(i:i+1))*rand(1);
            else
                x0(1,(i-1)*7+7)=0;
            end;
        end;
        
        options_0 = optimoptions('fmincon','Algorithm', 'interior-point', 'SubproblemAlgorithm', 'factorization', 'Display', 'notify', 'TolX', 1e-14, 'TolCon', 1e-10, 'TolFun', 1e-10, 'MaxIter', 4000, 'MaxFunEvals', 2e6); 
        options_opt = optimoptions('fmincon','Algorithm', 'interior-point', 'SubproblemAlgorithm', 'cg', 'Display', 'notify', 'TolX', 1e-14, 'TolCon', 1e-10, 'TolFun', 1e-10, 'MaxIter', 4000, 'MaxFunEvals', 2e6);
        
        tic
        [x1,E1] = fmincon(@(x)0,x0,[],[],Aeq,beq,LB,UB,@nonlcon_braking_curve_analytic,options_0);
        total_time0(xxx,1)=toc;
        tic
        [x2,E2] = fmincon(@energy_consumption_analytic,x1,[],[],Aeq,beq,LB,UB,@nonlcon_braking_curve_analytic,options_opt);
        total_time(xxx,1)=toc;
        output=[x1; x2];
        E(xxx,:)=[E1,E2];
        energy_consumption(xxx)=E2
        opt_result(xxx,:)=x2;
    end;
end;
