function [Mayer,Lagrange]=TrainSchedulingCost(sol)

t  = sol.initial.time;
x  = sol.state;
u  = sol.control;
Mayer    =  zeros(size(t));
Lagrange =  x(:,2).*u(:,1);
