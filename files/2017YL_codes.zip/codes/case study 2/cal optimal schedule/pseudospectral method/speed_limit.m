function sl = speed_limit(x)
global sl_table;
global station_location;
sl=x;
x=min(max(station_location(1),x),station_location(end));
for i=1:length(x)
    a=find(sl_table(:,3)<=x(i) & sl_table(:,4)>=x(i));
    sl(i)=sl_table(a(1), 2);
end;