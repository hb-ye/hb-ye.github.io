function gd = gradient_profile(x)
global gd_table;
global station_location;
gd=x;
x=min(max(station_location(1),x),station_location(end));
for i=1:length(x)
    a=find(gd_table(:,3)<=x(i) & gd_table(:,4)>=x(i));
    gd(i)=gd_table(a(1), 2);
end;