clear
clc

tic
NLP_epsilon=[1e-8,1e-8];
train_network_yizhuang
colpoints_num=30;
mesh_num=1;
mesh_iteration = 0;

global phase_num;
global station_location;
global running_time;

initial_guess_time=running_time_min;
for iphase=1:phase_num
    if iphase==1
        limits(iphase).time.min = [0, max(sum(running_time(1,1:iphase)), total_running_time-sum(running_time(2,iphase+1:end)))];
        limits(iphase).time.max = [0, min(sum(running_time(2,1:iphase)), total_running_time-sum(running_time(1,iphase+1:end)))];
    elseif iphase==phase_num
        limits(iphase).time.min = [max(sum(running_time(1,1:iphase-1)),total_running_time-sum(running_time(2,iphase:end))), total_running_time];
        limits(iphase).time.max = [min(sum(running_time(2,1:iphase-1)),total_running_time-sum(running_time(1,iphase:end))), total_running_time];
    else
        limits(iphase).time.min = [max(sum(running_time(1,1:iphase-1)),total_running_time-sum(running_time(2,iphase:end))), max(sum(running_time(1,1:iphase)), total_running_time-sum(running_time(2,iphase+1:end)))];
        limits(iphase).time.max = [min(sum(running_time(2,1:iphase-1)),total_running_time-sum(running_time(1,iphase:end))), min(sum(running_time(2,1:iphase)), total_running_time-sum(running_time(1,iphase+1:end)))];
    end;
    limits(iphase).state.min(1,:)   = [station_location(iphase), station_location(iphase), station_location(iphase+1)]; % location
    limits(iphase).state.max(1,:)   = [station_location(iphase), station_location(iphase+1), station_location(iphase+1)];
    limits(iphase).state.min(2,:)   = [0 0 0]; % speed
    limits(iphase).state.max(2,:)   = [0 23.61 0];
    limits(iphase).control.min = [0; 0];
    limits(iphase).control.max = [310; 260];
    limits(iphase).parameter.min    = [];
    limits(iphase).parameter.max    = [];
    limits(iphase).path.min    = [-23.61; -310; -260];
    limits(iphase).path.max    = [0; 0; 0];
    limits(iphase).duration.min = max(running_time(1, iphase),total_running_time-sum(running_time(2,:))+running_time(2, iphase));
    limits(iphase).duration.max = min(running_time(2, iphase),total_running_time-sum(running_time(1,:))+running_time(1, iphase));
    limits(iphase).nodesPerInterval = colpoints_num;
    
    guess(iphase).time = [sum(initial_guess_time(1,1:iphase-1)); sum(initial_guess_time(1,1:iphase))];
    guess(iphase).state(:,1) = [station_location(iphase); station_location(iphase+1)];
    guess(iphase).state(:,2) = [ 0; 0];
    guess(iphase).control(:,1) = [ 310; 0];
    guess(iphase).control(:,2) = [ 0; 260];
    guess(iphase).parameter = [];
end;

for iphase=1:phase_num
    limits(iphase).meshPoints = [-1:2/mesh_num:1];
    limits(iphase).nodesPerInterval = colpoints_num;
end

for ipair=1:phase_num-1
    linkages(ipair).left.phase = ipair;
    linkages(ipair).right.phase = ipair+1;
    linkages(ipair).min = [0];
    linkages(ipair).max = [0];
end;

setup.name = 'TrainScheduling';
setup.funcs.cost = 'TrainSchedulingCost';
setup.funcs.dae = 'TrainSchedulingDae';
setup.funcs.link = 'TrainSchedulingLink';
setup.limits = limits;
setup.derivatives = 'complex';
setup.guess = guess;
setup.linkages = linkages;
setup.autoscale = 'off';
setup.tolerances = NLP_epsilon;
setup.mesh.iteration = mesh_iteration ;
setup.printoff = 0;

output = gpops(setup);
toc;
solution = output.solution;
for iphase=1:length(solution)
    running_time_opt(iphase) = solution(iphase).time(end)-solution(iphase).time(1);
end;
running_time_opt'
