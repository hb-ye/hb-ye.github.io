function link = TrainSchedulingLink(sol)

link = [0];
