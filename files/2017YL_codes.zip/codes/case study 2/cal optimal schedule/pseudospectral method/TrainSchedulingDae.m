function dae = TrainSchedulingDae(sol)

t = sol.time;
y = sol.state;
a = sol.control; % acceleration/deceleration is the control variable
x = y(:,1);
v = y(:,2);
xdot = v;
vdot = (a(:,1)-a(:,2))/278-(1.0393*v.^2/10^4+0.0142)-9.80665*gradient_profile(x); % tractive/braking: N; resistance: N/kg
path=[v-speed_limit(x), a(:,1)-min(310, 310-5*(3.6*v-36)), a(:,2)-min(260, 260-5*(3.6*v-60))];
dae = [xdot vdot path];
