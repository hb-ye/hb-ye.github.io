function [s,v]=solve_ode(a,b,c,t,v0)

X=sqrt(abs(4*a*c-b^2))/(2*a);

if abs(4*a*c-b^2)<1e-6
    if abs(-b/(2*a)-v0)<1e-6
        v=v0;
        s=v0*t;
    else
        v=1/(-a*t+2*a/(2*a*v0+b))-b/(2*a);
        s=-a*log(abs(1-(a*v0+b/2)*t))-b/(2*a)*t;
    end;
elseif 4*a*c>b^2
    v=X*tan(a*X*t+atan(v0/X+b/(2*a*X)))-b/(2*a);
    s=-1/a*log(abs(cos(a*X*t+atan(v0/X+b/(2*a*X)))/cos(atan(v0/X+b/(2*a*X)))))-b/(2*a)*t;
else % 4*a*c<b^2
    if abs(X-b/(2*a)-v0)<1e-6 || abs(-X-b/(2*a)-v0)<1e-6
        v=v0;
        s=v0*t;
    else
        v=2*X/(1-(2*a*(v0-X)+b)/(2*a*(v0+X)+b)*exp(2*a*X*t))-b/(2*a)-X;
        s=-1/a*log(abs(((2*a*(v0+X)+b)-(2*a*(v0-X)+b)*exp(2*a*X*t))/(4*a*X)))+(X-b/(2*a))*t;
    end;
end;