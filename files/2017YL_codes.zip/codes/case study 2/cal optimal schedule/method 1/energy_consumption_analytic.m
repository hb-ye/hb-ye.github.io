function E = energy_consumption_analytic(x)

global subsection_num;
global current_speed;
global gd;
global a_r  b_r  c_r  a_max;

E=0;
t_a = x(7*[1:subsection_num]-6);
t_s = x(7*[1:subsection_num]-5);
v_0 = [current_speed, x(7*[1:subsection_num-1])];
v_a = x(7*[1:subsection_num]-2);
for i=1:subsection_num
    % max traction
    E=E + cal_energy(-a_r,-b_r,a_max-c_r-9.80665*(gd(i)),-a_r,-b_r-18/278,490/278-c_r-9.80665*(gd(i)),t_a(i),v_0(i),10, 310/278, 490/278, -18/278);

    % speedholding
    s_s=v_a(i)*t_s(i); 
    E=E + max(0, 1.0393*v_a(i)^2/10^4+0.0142 + 9.80665*(gd(i)))*s_s;
end;
