clear;
clc;

global section_num;
global subsection_num;
global sl;
global gd;
global subsection_length;
global total_running_time;
global current_speed;
global subsection_list;
train_network_yizhuang

subsection_length_max=2000;
subsection_mark=sort(unique([sl_table(:,3);sl_table(end,4); gd_table(:,3);gd_table(end,4);station_location']));
subsection_mark_new=[];
for i=1:length(subsection_mark)-1
    subsection_mark_new=[subsection_mark_new; subsection_mark(i,:)];
    subsection_length_i=subsection_mark(i+1)-subsection_mark(i);
    divide_num=ceil(subsection_length_i/subsection_length_max);
    if divide_num>1
        for k=1:divide_num-1
            subsection_mark_new=[subsection_mark_new; subsection_mark(i,:)+ k*subsection_length_i/divide_num];
        end;
    end;
end;
subsection_mark_new=[subsection_mark_new; subsection_mark(end)];
subsection_mark=subsection_mark_new;

subsection_list=[subsection_mark(1:end-1), subsection_mark(2:end)];
for i=1:size(subsection_list,1)
    subsection_list(i,3)=gd_table(find(subsection_list(i,1)>=gd_table(:,3) & subsection_list(i,1)<=gd_table(:,4) & subsection_list(i,2)>=gd_table(:,3) & subsection_list(i,2)<=gd_table(:,4)),2);
    subsection_list(i,4)=sl_table(find(subsection_list(i,1)>=sl_table(:,3) & subsection_list(i,1)<=sl_table(:,4) & subsection_list(i,2)>=sl_table(:,3) & subsection_list(i,2)<=sl_table(:,4)),2);
end;

section_end=zeros(section_num,1);
for i_section=1:section_num
    section_end(i_section)=find(subsection_list(:,2)==station_location(i_section+1));
end;
section_start=[1; section_end(1:end-1)+1];

subsection_list=subsection_list([1:section_end(section_num)],:);
subsection_num=size(subsection_list,1);
sl=subsection_list(:,4)';
gd=subsection_list(:,3)';
subsection_length=[subsection_list(:,2)-subsection_list(:,1)]';
total_running_time=sum(running_time_origin(1:section_num));
current_speed = 0;
min_sub_running_time=subsection_length./sl;

global a_r  b_r  c_r  a_max  a_min;
a_r=1.0393/10^4;
b_r=0;
c_r=0.0142;
a_max=310/278;
a_min=260/278;

subsection_num_in_section=zeros(1,station_num-1);
for i_section=1:station_num-1
    subsection_num_in_section(i_section)=find(subsection_list(:,2)==station_location(i_section+1))-find(subsection_list(:,1)==station_location(i_section))+1;
end;
nvars=7*subsection_num;
LB=zeros(7*subsection_num,1);
UB_t=zeros(subsection_num,1);
for i_section=1:station_num-1
    temp=[sum(subsection_num_in_section(1:i_section-1))+1:sum(subsection_num_in_section(1:i_section))];
    UB_t(temp)=running_time(2,i_section)-sum(min_sub_running_time(temp))+min_sub_running_time(temp);
end;
UB=zeros(7*subsection_num,1);
for i=1:subsection_num
    UB(7*(i-1)+[1:4])=UB_t(i);
    UB(7*(i-1)+[5:6])=sl(i);
    if ismember(i,section_end)
        UB(7*i)=0;
    else
        UB(7*i)=min(sl(i), sl(i+1));
    end;
end;
Aeq=repmat([ones(1,4), zeros(1,3)], 1, subsection_num);
beq=total_running_time;
Aneq=zeros(section_num*2,nvars);
bneq=zeros(section_num*2,1);
for i=1:section_num
    for j=section_start(i):section_end(i)
        Aneq(i,(j-1)*7+[1:4])=1;
        Aneq(i+section_num,(j-1)*7+[1:4])=-1;
    end;
    bneq(i)=running_time(2,i);
    bneq(i+section_num)=-running_time(1,i);
end;

trial_num=2;
energy_consumption=zeros(trial_num,1);
opt_result=zeros(trial_num, subsection_num*7);
for xxx=1:trial_num
    x0=zeros(1,nvars);

    x0_t=zeros(1, subsection_num);
    for i_section=1:station_num-1
        total_running_time=running_time(1,i_section)+rand*(running_time(2,i_section)-running_time(1,i_section));
        temp=[sum(subsection_num_in_section(1:i_section-1))+1:sum(subsection_num_in_section(1:i_section))];
        rand_temp=rand(1,length(temp));
        x0_t(temp)=min_sub_running_time(temp)+rand_temp./sum(rand_temp)*(total_running_time-sum(min_sub_running_time(temp)));
    end;

    for i=1:subsection_num
        rand_temp=rand(1,4);
        x0(1,(i-1)*7+[1:4])=x0_t(i)*rand_temp./sum(rand_temp);
        x0(1,(i-1)*7+[5:6])=sl(i)*rand(1);
        if ismember(i,section_end)
            x0(1,(i-1)*7+7)=0;
        else
            x0(1,(i-1)*7+7)=min(sl(i:i+1))*rand(1);
        end;
    end;

    options_0 = optimoptions('fmincon','Algorithm', 'interior-point', 'SubproblemAlgorithm', 'factorization', 'Display', 'notify', 'TolX', 1e-14, 'TolCon', 1e-10, 'TolFun', 1e-10, 'MaxIter', 4000, 'MaxFunEvals', 2000000);
    options_opt = optimoptions('fmincon','Algorithm', 'interior-point', 'SubproblemAlgorithm', 'cg', 'Display', 'notify', 'TolX', 1e-14, 'TolCon', 1e-10, 'TolFun', 1e-10, 'MaxIter', 4000, 'MaxFunEvals', 2000000);
    
    tic
    [x1,E1,exitflag,~] = fmincon(@(x)0,x0,Aneq,bneq,Aeq,beq,LB,UB,@nonlcon_braking_curve_analytic,options_0);
    total_time_0(xxx,1)=toc;
    exit_flag_0(xxx,1)=exitflag;
    tic
    [x2,E2,exitflag,~] = fmincon(@(x) 1*energy_consumption_analytic(x),x1,Aneq,bneq,Aeq,beq,LB,UB,@nonlcon_braking_curve_analytic,options_opt);
    total_time_opt(xxx,1)=toc;
    exit_flag_opt(xxx,1)=exitflag;
    total_time(xxx,1)=total_time_0(xxx,1)+total_time_opt(xxx,1);
    output=[x1; x2];
    E(xxx,:)=[E1,E2];
    energy_consumption(xxx)=E2;
    opt_result(xxx,:)=x2;
end;

yyy=find(exit_flag_opt==2);
trial_num-length(yyy)
[max(total_time(yyy)), mean(total_time(yyy)), min(total_time(yyy))]
[max(energy_consumption(yyy)), mean(energy_consumption(yyy)), min(energy_consumption(yyy))]
exit_flag_opt(find(exit_flag_opt~=2))

opt_time=[];
for i=1:101
    opt_time=[opt_time,sum(opt_result(:,7*(i-1)+[1:4]),2)];
end
opt_running_time=[];
for i_section=1:station_num-1
    opt_running_time=[opt_running_time,sum(opt_time(:,sum(subsection_num_in_section(1:i_section-1))+1:sum(subsection_num_in_section(1:i_section))),2)];
end;
temp=[max(opt_running_time,[],1); mean(opt_running_time,1); min(opt_running_time,[],1)]

save opt_schedule.mat;
