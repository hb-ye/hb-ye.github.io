clear;
clc;

global section_num;
global sl;
global gd;
global subsection_length;
global total_running_time;
global current_speed;
global subsection_list;
train_network_yizhuang

subsection_length_max=2000;
subsection_mark=sort(unique([sl_table(:,3);sl_table(end,4); gd_table(:,3);gd_table(end,4);station_location']));
subsection_mark_new=[];
for i=1:length(subsection_mark)-1
    subsection_mark_new=[subsection_mark_new; subsection_mark(i,:)];
    subsection_length_i=subsection_mark(i+1)-subsection_mark(i);
    divide_num=ceil(subsection_length_i/subsection_length_max);
    if divide_num>1
        for k=1:divide_num-1
            subsection_mark_new=[subsection_mark_new; subsection_mark(i,:)+ k*subsection_length_i/divide_num];
        end;
    end;
end;
subsection_mark_new=[subsection_mark_new; subsection_mark(end)];
subsection_mark=subsection_mark_new;

subsection_list=[subsection_mark(1:end-1), subsection_mark(2:end)];
for i=1:size(subsection_list,1)
    subsection_list(i,3)=gd_table(find(subsection_list(i,1)>=gd_table(:,3) & subsection_list(i,1)<=gd_table(:,4) & subsection_list(i,2)>=gd_table(:,3) & subsection_list(i,2)<=gd_table(:,4)),2);
    subsection_list(i,4)=sl_table(find(subsection_list(i,1)>=sl_table(:,3) & subsection_list(i,1)<=sl_table(:,4) & subsection_list(i,2)>=sl_table(:,3) & subsection_list(i,2)<=sl_table(:,4)),2);
end;
subsection_list_whole_line=subsection_list;

for i_section=1:station_num-1
    subsection_list=subsection_list_whole_line([find(subsection_list_whole_line(:,1)==station_location(i_section)):find(subsection_list_whole_line(:,2)==station_location(i_section+1))],:);
    
    section_num=size(subsection_list,1);
    sl=subsection_list(:,4)';
    gd=subsection_list(:,3)';
    subsection_length=[subsection_list(:,2)-subsection_list(:,1)]';
    total_running_time=current_arrival(i_section)-current_departure(i_section);
    current_speed = 0;
    min_sub_running_time=subsection_length./sl;
    
    global a_r  b_r  c_r  a_max  a_min;
    a_r=1.0393/10^4;
    b_r=0;
    c_r=0.0142;
    a_max=310/278;
    a_min=260/278;
    
    nvars=7*section_num+1;
    LB=zeros(7*section_num,1);
    UB=zeros(7*section_num,1);
    for i=1:section_num
        UB(7*(i-1)+[1:4])=total_running_time-sum(min_sub_running_time)+min_sub_running_time(i);
        UB(7*(i-1)+[5:6])=sl(i);
        if i~=section_num
            UB(7*i)=min(sl(i), sl(i+1));
        else
            UB(7*i)=0;
        end;
    end;
    LB=[LB;0];
    UB=[UB;total_running_time];
    Aeq=[repmat([ones(1,4), zeros(1,3)], 1, section_num),-1];
    beq=0;
    
    trial_num=30;
    energy_consumption=zeros(trial_num,1);
    opt_result=zeros(trial_num, section_num*7);
    for xxx=1:trial_num
        x0=zeros(1,nvars);

        x0_t=rand(1, section_num);
        x0_t=min_sub_running_time+x0_t./sum(x0_t)*(total_running_time-sum(min_sub_running_time));
        x0_t_temp=x0_t;
        for i=1:section_num
            rand_temp=rand(1,4);
            x0_t(1,4*(i-1)+[1:4])=rand_temp./sum(rand_temp)*x0_t_temp(i);
        end;
        
        for i=1:section_num
            x0(1,(i-1)*7+[1:4])=x0_t((i-1)*4+[1:4]); 
            x0(1,(i-1)*7+[5:6])=sl(i)*rand(1);
            if i~=section_num
                x0(1,(i-1)*7+7)=min(sl(i:i+1))*rand(1);
            else
                x0(1,(i-1)*7+7)=0;
            end;
        end;
        x0(1,nvars)=total_running_time;
        
        options_0 = optimoptions('fmincon','Algorithm', 'interior-point', 'SubproblemAlgorithm', 'factorization', 'Display', 'notify', 'TolX', 1e-14, 'TolCon', 1e-10, 'TolFun', 1e-10, 'MaxIter', 4000, 'MaxFunEvals', 2000000);
        options_opt = optimoptions('fmincon','Algorithm', 'interior-point', 'SubproblemAlgorithm', 'cg', 'Display', 'notify', 'TolX', 1e-14, 'TolCon', 1e-10, 'TolFun', 1e-10, 'MaxIter', 4000, 'MaxFunEvals', 2000000); 
        
        tic
        [x1,E1,exitflag,~] = fmincon(@(x)0,x0,[],[],Aeq,beq,LB,UB,@nonlcon_braking_curve_analytic,options_0);
        total_time_0(xxx,1)=toc;
        exit_flag_0(xxx,1)=exitflag;
        tic
        [x2,E2,exitflag,~] = fmincon(@(x)sum([zeros(1,7*section_num),1].*x),x1,[],[],Aeq,beq,LB,UB,@nonlcon_braking_curve_analytic,options_opt);
        total_time_opt(xxx,1)=toc;
        exit_flag_opt(xxx,1)=exitflag;
        total_time(xxx,1)=total_time_0(xxx,1)+total_time_opt(xxx,1);
        output=[x1(end); x2(end)];
        E(xxx,:)=[E1,E2];
        energy_consumption(xxx)=E2;
        opt_result(xxx,:)=x2(end);
    end;

    i_section
    yyy=find(exit_flag_opt==2 | exit_flag_opt==1);
    trial_num-length(yyy)
    [max(total_time(yyy)), mean(total_time(yyy)), min(total_time(yyy))]
    [max(energy_consumption(yyy)), mean(energy_consumption(yyy)), min(energy_consumption(yyy))]
end;
