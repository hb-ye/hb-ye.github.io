clear;
clc;
load('method_1_original.mat');

global section_num;
global sl;
global gd;
global subsection_length;
global total_running_time;
global current_speed;
global subsection_list;
    
TolX_val=1e-14;
TolCon_val=1e-10;
TolFun_val=1e-10;
MaxIter_val=4000;
MaxFunEvals_val=2000000;

train_network_yizhuang

subsection_list=[	   0     150    -0.002	13.89
					 150     160    -0.002	23.61
					 160     470    -0.003	23.61
					 470     480     0.0104	23.61
					 480     970     0.0104	18.06
					 970    1161	 0.003	18.06
					1161	1370 	 0.003	23.61
					1370	1880	-0.008	23.61
					1880	2500	 0.003	23.61
					2500	2501	-0.002	23.61
					2501	2643	-0.002	16.67
					2643	2770	-0.002	23.61
					2770	2797	-0.003	23.61
					2797	3170	-0.003	20.83
					3170	3534	 0.0082	20.83
					3534	3570	 0.0082	23.61
					3570	3780	 0.002	23.61
					3780	3918	 0.002	16.67
					3918	3940	 0.002	23.61
					3940	4200	-0.0204	23.61
					4200	4800	-0.024	23.61
					4800	5200	 0      23.61
					5200	5800	-0.002	23.61
					5800	5808	-0.0032	23.61
					5808	6050	-0.0032	20.83
					6050	6141	 0      20.83
					6141	6271	 0      16.67];

section_num=size(subsection_list,1);
sl=subsection_list(:,4)';
gd=subsection_list(:,3)';
subsection_length=[subsection_list(:,2)-subsection_list(:,1)]';
total_running_time=370;
current_speed = 0;
min_sub_running_time=subsection_length./sl;

global a_r  b_r  c_r  a_max  a_min;
a_r=1.0393/10^4;
b_r=0;
c_r=0.0142;
a_max=310/278;
a_min=260/278;

nvars=7*section_num;

trial_num=10; % number of trials
opt_result_modified=zeros(trial_num, section_num*7);
operation_kept_tag_all=zeros(trial_num,section_num*7);

for xxx=1:trial_num
    xxx;
    LB=zeros(7*section_num,1);
    UB=zeros(7*section_num,1);
    for i=1:section_num
        UB(7*(i-1)+[1:4])=total_running_time-sum(min_sub_running_time)+min_sub_running_time(i);
        UB(7*(i-1)+[5:6])=sl(i);
        if i~=section_num
            UB(7*i)=min(sl(i), sl(i+1));
        else
            UB(7*i)=0;
        end;
    end;
    Aeq=repmat([ones(1,4), zeros(1,3)], 1, section_num);
    beq=total_running_time;
    options_0=optimoptions('fmincon','Algorithm', 'interior-point', 'SubproblemAlgorithm', 'factorization', 'Display', 'notify', 'TolX', TolX_val, 'TolCon', TolCon_val, 'TolFun', TolFun_val, 'MaxIter', MaxIter_val, 'MaxFunEvals', MaxFunEvals_val);
    options_opt = optimoptions('fmincon','Algorithm', 'interior-point', 'SubproblemAlgorithm', 'cg', 'Display', 'notify', 'TolX', TolX_val, 'TolCon', TolCon_val, 'TolFun', TolFun_val, 'MaxIter', MaxIter_val, 'MaxFunEvals', MaxFunEvals_val);

    x2=opt_result(xxx,:);
    tic
    operation_kept_tag=ones(1,7*section_num);
    for i=1:section_num
        for j=[7*(i-1)+[1:4]]
            if i==1 && j==1
            elseif i==section_num && j==7*(section_num-1)+4
            else 
                if x2(j)<max(x2(7*(i-1)+[1:4])) && x2(j)<1
                    operation_kept_tag(j)=0;
                end;
            end;
        end;
    end;

    for i=1:section_num
        if ~operation_kept_tag(7*(i-1)+1)
            operation_kept_tag(7*(i-1)+5)=0;
        end;
        if ~operation_kept_tag(7*(i-1)+3)
            operation_kept_tag(7*(i-1)+6)=0;
        end;
        if ~operation_kept_tag(7*(i-1)+4)
            operation_kept_tag(7*(i-1)+7)=0;
        end;
    end;

    for i=2:section_num
        for j=1:4
            if operation_kept_tag(7*(i-1)+j)
                if j==2 && j==3
                    UB(7*(i-1)+5)=min(sl(i-1),sl(i));
                elseif j==4
                    UB(7*(i-1)+6)=min(sl(i-1),sl(i));
                end;
                break;
            end;
        end;
    end;
    for i=1:section_num-1
        for j=4:-1:1
            if operation_kept_tag(7*(i-1)+j)
                if j==3
                    UB(7*(i-1)+6)=min(sl(i),sl(i+1));
                elseif j==2 && j==1
                    UB(7*(i-1)+5)=min(sl(i),sl(i+1));
                end;
                break;
            end;
        end;
    end;
    
    x0=x2;
    
    a=find(operation_kept_tag==1);
    LB=LB(a);
    UB=UB(a);
    x0=x0(a);
    Aeq=Aeq(:,a);

    [x4,E4,exitflag,~] = fmincon(@(x)energy_consumption_analytic_rem(x,operation_kept_tag),x0,[],[],Aeq,beq,LB,UB,@(x)nonlcon_braking_curve_analytic_rem(x,operation_kept_tag),options_opt);
    total_time_opt_modified(xxx,1)=toc;
    exit_flag_opt_modified(xxx,1)=exitflag;

    energy_consumption_modified(xxx,:)=E4;
    a=find(operation_kept_tag==1);
    opt_result_modified(xxx,a)=x4;
    operation_kept_tag_all(xxx,:)=operation_kept_tag;
end;

yyy=find(exit_flag_opt==2 & exit_flag_opt_modified==2);
[length(find(exit_flag_opt==2))-length(yyy), length(find(exit_flag_opt==2))]
[max(total_time_opt_modified(yyy)), mean(total_time_opt_modified(yyy)), min(total_time_opt_modified(yyy))]
[max(energy_consumption_modified(yyy)), mean(energy_consumption_modified(yyy)), min(energy_consumption_modified(yyy))]
exit_flag_opt_modified(find(exit_flag_opt==2 & exit_flag_opt_modified~=2))'

temp_figure