function E = energy_consumption_analytic_rem(x, operation_kept_tag)

global section_num;
global current_speed;
global gd;
global a_r  b_r  c_r  a_max;

x_new=zeros(1,7*section_num);
x_new(find(operation_kept_tag==1))=x;
x=x_new;

E=0;

t_a = x(7*[1:section_num]-6);
t_s = x(7*[1:section_num]-5);
v_0 = [current_speed, x(7*[1:section_num-1])];
v_a = x(7*[1:section_num]-2);
v_b = x(7*[1:section_num]-1);

for i=1:section_num
    if ~operation_kept_tag(7*(i-1)+1)
        v_a(i)=v_0(i);
    end;
    if ~operation_kept_tag(7*(i-1)+3)
        v_b(i)=v_a(i);
    end;
    if ~operation_kept_tag(7*(i-1)+4)
        v_0(i+1)=v_b(i);
    end;
end;

for i=1:section_num
    % max traction
    if operation_kept_tag(7*(i-1)+1)
        E=E + cal_energy(-a_r,-b_r,a_max-c_r-9.80665*(gd(i)),-a_r,-b_r-18/278,490/278-c_r-9.80665*(gd(i)),t_a(i),v_0(i),10, 310/278, 490/278, -18/278);
    end;
    
    % speedholding
    if operation_kept_tag(7*(i-1)+2)
        s_s=v_a(i)*t_s(i);
        E=E + max(0, 1.0393*v_a(i)^2/10^4+0.0142 + 9.80665*(gd(i)))*s_s;
    end;
end;
