function [c,ceq] = nonlcon_braking_curve_analytic(x)

global section_num;
global current_speed;
global gd;
global subsection_length;
global a_r  b_r  c_r  a_max  a_min;

t_a = x(7*[1:section_num]-6);
t_s = x(7*[1:section_num]-5);
t_c = x(7*[1:section_num]-4);
t_b = x(7*[1:section_num]-3);
v_a = x(7*[1:section_num]-2);
v_b = x(7*[1:section_num]-1);
v_f = x(7*[1:section_num]);
v_0 = [current_speed, v_f(1:section_num-1)];

c=zeros(2*section_num,1);
ceq=zeros(6*section_num,1);
for i=1:section_num
    % max traction
    [s_a,v_a_temp] = solve_ode_piecewise(-a_r,-b_r,a_max-c_r-9.80665*(gd(i)),-a_r,-b_r-18/278,490/278-c_r-9.80665*(gd(i)),t_a(i),v_0(i),10);
    
    % speedholding
    s_s=v_a(i)*t_s(i);
    
    % coasting
    [s_c,v_b_temp] = solve_ode(-a_r,-b_r,0-c_r-9.80665*(gd(i)), t_c(i), v_a(i));
    
    % max braking
    [s_b,v_f_temp] = solve_ode_piecewise(-a_r,-b_r,-a_min-c_r-9.80665*(gd(i)),-a_r,-b_r+18/278,-560/278-c_r-9.80665*(gd(i)), t_b(i), v_b(i),50/3); 
    ceq(4*(i-1)+[1:4])=[v_a_temp-v_a(i); v_b_temp-v_b(i); v_f_temp-v_f(i); s_a+s_s+s_c+s_b-subsection_length(i)];
    c(2*(i-1)+[1:2])=[-t_s(i)*(a_r*v_a(i)^2+b_r*v_a(i)+c_r+9.80665*gd(i)+min(260,260-5*(3.6*v_a(i)-60))/278), t_s(i) * (a_r*v_a(i)^2+b_r*v_a(i)+c_r+9.80665*gd(i)-min(310,310-5*(3.6*v_a(i)-36))/278)];
end;
