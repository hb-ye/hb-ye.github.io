function E=solve_energy_linear(a,b,c,t,v0,F_intercept,F_slope)

X=sqrt(abs(4*a*c-b^2))/(2*a);

if 4*a*c==b^2
    if v0==-b/(2*a)
        s=v0*t;
        E=F_intercept*s+F_slope*v0^2*t;
    else
        s=-a*log(abs(1-(a*v0+b/2)*t))-b/(2*a)*t;
        E=F_intercept*s+F_slope*(1/a^2*(1/(2/(2*a*v0+b)-t)-(2*a*v0+b)/2)+b/a^2*log(abs((2*a*v0+b)/2*t-1))+(b/(2*a))^2*t);
    end;
elseif 4*a*c>b^2
    s=-1/a*log(abs(cos(a*X*t+atan(v0/X+b/(2*a*X)))/cos(atan(v0/X+b/(2*a*X)))))-b/(2*a)*t;
    E=F_intercept*s+F_slope*(X/a*tan(a*X*t+atan(v0/X+b/(2*a*X)))+((b/(2*a))^2-X^2)*t+b/a^2*log(abs(cos(a*X*t+atan(v0/X+b/(2*a*X)))/cos(atan(v0/X+b/(2*a*X)))))-1/a*(v0+b/(2*a)));
else % 4*a*c<b^2
    if v0==X-b/(2*a) || v0==-X-b/(2*a)
        s=v0*t;
        E=F_intercept*s+F_slope*v0^2*t;
    else
        s=-1/a*log(abs(((2*a*(v0+X)+b)-(2*a*(v0-X)+b)*exp(2*a*X*t))/(4*a*X)))+(X-b/(2*a))*t;
        y=(2*a*(v0-X)+b)/(2*a*(v0+X)+b);
        E=F_intercept*s+F_slope*(2*X/a*(1/(1-y*exp(2*a*X*t))-1/(1-y))+b/a^2*log(abs((1-y*exp(2*a*X*t))/(1-y)))+(X-b/(2*a))^2*t);
    end;
end;
