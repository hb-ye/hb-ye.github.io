function E=cal_energy(a1,b1,c1,a2,b2,c2,t,v0,v_critical,F_max,F_intercept,F_slope)

if v0<v_critical
    X=sqrt(abs(4*a1*c1-b1^2))/(2*a1);
    if abs(4*a1*c1-b1^2)<1e-6
        if abs(-b1/(2*a1)-v0)<1e-6
%             v=v0;
            s=v0*t;
            E=s*F_max;
        else
            if a1>0
                t_critical=2*(1/(2*a1*v0+b)-1/(2*a1*v_critical+b));
                if t<=t_critical
%                     v=1/(-a1*t+2*a1/(2*a1*v0+b1))-b1/(2*a1);
                    s=-a1*log(abs(1-(a1*v0+b1/2)*t))-b1/(2*a1)*t;
                    E=s*F_max;
                else % switch I -> II
                    s_critical=-a1*log(abs(1-(a1*v0+b1/2)*t_critical))-b1/(2*a1)*t_critical;
                    E1=s_critical*F_max;
                    E2=solve_energy_linear(a2,b2,c2,t-t_critical,v_critical,F_intercept,F_slope);
                    E=E1+E2;
                end;
            else 
%                 v=1/(-a1*t+2*a1/(2*a1*v0+b1))-b1/(2*a1);
                s=-a1*log(abs(1-(a1*v0+b1/2)*t))-b1/(2*a1)*t;
                E=s*F_max;
            end;
        end;
    elseif 4*a1*c1>b1^2 
        if a1>0
            t_critical=1/(a1*X)*(atan(v_critical/X+b/(2*a1*X))-atan(v0/X+b/(2*a1*X)));
            if t<=t_critical
%                 v=X*tan(a1*X*t+atan(v0/X+b1/(2*a1*X)))-b1/(2*a1);
                s=-1/a1*log(abs(cos(a1*X*t+atan(v0/X+b1/(2*a1*X)))/cos(atan(v0/X+b1/(2*a1*X)))))-b1/(2*a1)*t;
                E=s*F_max;
            else % switch I -> II
                s_critical=-1/a1*log(abs(cos(a1*X*t_critical+atan(v0/X+b1/(2*a1*X)))/cos(atan(v0/X+b1/(2*a1*X)))))-b1/(2*a1)*t_critical;
                E1=s_critical*F_max;
                E2=solve_energy_linear(a2,b2,c2,t-t_critical,v_critical,F_intercept,F_slope);
                E=E1+E2;
            end
        else
%             v=X*tan(a1*X*t+atan(v0/X+b1/(2*a1*X)))-b1/(2*a1);
            s=-1/a1*log(abs(cos(a1*X*t+atan(v0/X+b1/(2*a1*X)))/cos(atan(v0/X+b1/(2*a1*X)))))-b1/(2*a1)*t;
            E=s*F_max;
        end;
    else % 4*a1*c1 < b1^2
        if abs(X-b1/(2*a1)-v0)<1e-6 || abs(-X-b1/(2*a1)-v0)<1e-6
%             v=v0;
            s=v0*t;
            E=s*F_max;
        else
            if a1*(2*a1*(v0-X)+b1)/(2*a1*(v0+X)+b1)>0 && (2*a1*(v0+X)+b1)/(2*a1*(v0-X)+b1)*(2*a1*(v_critical-X)+b1)/(2*a1*(v_critical+X)+b1)>0 % Modified
                t_critical=1/(2*a1*X)*log((2*a1*(v0+X)+b1)/(2*a1*(v0-X)+b1)*(2*a1*(v_critical-X)+b1)/(2*a1*(v_critical+X)+b1));
                if t<=t_critical
%                     v=2*X/(1-(2*a1*(v0-X)+b1)/(2*a1*(v0+X)+b1)*exp(2*a1*X*t))-b1/(2*a1)-X;
                    s=-1/a1*log(abs(((2*a1*(v0+X)+b1)-(2*a1*(v0-X)+b1)*exp(2*a1*X*t))/(4*a1*X)))+(X-b1/(2*a1))*t;
                    E=s*F_max;
                else % switch I -> II
                    s_critical=-1/a1*log(abs(((2*a1*(v0+X)+b1)-(2*a1*(v0-X)+b1)*exp(2*a1*X*t_critical))/(4*a1*X)))+(X-b1/(2*a1))*t_critical;
                    E1=s_critical*F_max;
                    E2=solve_energy_linear(a2,b2,c2,t-t_critical,v_critical,F_intercept,F_slope);
                    E=E1+E2;
                end;
            else
%                 v=2*X/(1-(2*a1*(v0-X)+b1)/(2*a1*(v0+X)+b1)*exp(2*a1*X*t))-b1/(2*a1)-X;
                s=-1/a1*log(abs(((2*a1*(v0+X)+b1)-(2*a1*(v0-X)+b1)*exp(2*a1*X*t))/(4*a1*X)))+(X-b1/(2*a1))*t;
                E=s*F_max;
            end;
        end;
    end;
else % v0 > v_critical
    X=sqrt(abs(4*a2*c2-b2^2))/(2*a2);
    if abs(4*a2*c2-b2^2)<1e-6
        if abs(-b2/(2*a2)-v0)<1e-6
%             v=v0;
            E=solve_energy_linear(a2,b2,c2,t,v0,F_intercept,F_slope);
        else
            if a2<0
                t_critical=2*(1/(2*a2*v0+b)-1/(2*a2*v_critical+b));
                if t<=t_critical
%                     v=1/(-a2*t+2*a2/(2*a2*v0+b2))-b2/(2*a2);
                    E=solve_energy_linear(a2,b2,c2,t,v0,F_intercept,F_slope);
                else % switch II -> I
                    E2=solve_energy_linear(a2,b2,c2,t_critical,v0,F_intercept,F_slope);
                    [s,~]=solve_ode(a1,b1,c1,t-t_critical,v_critical);
                    E=E2+s*F_max;
                end;
            else 
%                 v=1/(-a2*t+2*a2/(2*a2*v0+b2))-b2/(2*a2);
                E=solve_energy_linear(a2,b2,c2,t,v0,F_intercept,F_slope);
            end;
        end;
    elseif 4*a2*c2>b2^2 
        if a2<0
            t_critical=1/(a2*X)*(atan(v_critical/X+b/(2*a2*X))-atan(v0/X+b/(2*a2*X)));
            if t<=t_critical
%                 v=X*tan(a2*X*t+atan(v0/X+b2/(2*a2*X)))-b2/(2*a2);
                E=solve_energy_linear(a2,b2,c2,t,v0,F_intercept,F_slope);
            else % switch II -> I
                E2=solve_energy_linear(a2,b2,c2,t_critical,v0,F_intercept,F_slope);
                [s,~]=solve_ode(a1,b1,c1,t-t_critical,v_critical);
                E=E2+s*F_max;
            end
        else
%             v=X*tan(a2*X*t+atan(v0/X+b2/(2*a2*X)))-b2/(2*a2);
            E=solve_energy_linear(a2,b2,c2,t,v0,F_intercept,F_slope);
        end;
    else % 4*a2*c2 < b2^2
        if abs(X-b2/(2*a2)-v0)<1e-6 || abs(-X-b2/(2*a2)-v0)<1e-6
%             v=v0;
            E=solve_energy_linear(a2,b2,c2,t,v0,F_intercept,F_slope);
        else
            if a2*(2*a2*(v0-X)+b2)/(2*a2*(v0+X)+b2)<0 && (2*a2*(v0+X)+b2)/(2*a2*(v0-X)+b2)*(2*a2*(v_critical-X)+b2)/(2*a2*(v_critical+X)+b2)>0 % Modified
                t_critical=1/(2*a2*X)*log((2*a2*(v0+X)+b2)/(2*a2*(v0-X)+b2)*(2*a2*(v_critical-X)+b2)/(2*a2*(v_critical+X)+b2));
                if t<=t_critical
                    E=solve_energy_linear(a2,b2,c2,t,v0,F_intercept,F_slope);
                else % switch II -> I
                    E2=solve_energy_linear(a2,b2,c2,t_critical,v0,F_intercept,F_slope);
                    [s,~]=solve_ode(a1,b1,c1,t-t_critical,v_critical);
                    E=E2+s*F_max;
                end;
            else
%                 v=2*X/(1-(2*a2*(v0-X)+b2)/(2*a2*(v0+X)+b2)*exp(2*a2*X*t))-b2/(2*a2)-X;
                E=solve_energy_linear(a2,b2,c2,t,v0,F_intercept,F_slope);
            end;
        end;
    end;
end;