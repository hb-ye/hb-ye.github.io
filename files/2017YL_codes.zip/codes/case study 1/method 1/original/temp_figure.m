energy_consumption_simulation=[];
for i_trial=1:trial_num 
    if exit_flag_opt(i_trial)~=2
        continue;
    end;
    t_duration=zeros(section_num*4,1);
    for i=1:section_num
        t_duration(4*(i-1)+[1:4])=opt_result(i_trial, 7*(i-1)+[1:4])';
    end;
    t_vector=cumsum([0;t_duration]);
    T=0;
    Y=[0,0,0];
    options = odeset('RelTol',1e-12);
    F_max=[];
    F_applied=[];
    B_max=[];
    for i=1:section_num
        for j=1:4
            if t_duration(4*(i-1)+j)>1e-2
                [T_temp, Y_temp]=ode45(@temp_dynamics, [t_vector(4*(i-1)+j),t_vector(4*(i-1)+j+1)], Y(end,:), options, j);
                T=[T; T_temp];
                Y=[Y; Y_temp];
                F_max_temp = min(310,310-5*(3.6*Y_temp(:,2)-36))/278;
                B_max_temp = min(260,260-5*(3.6*Y_temp(:,2)-60))/278;
                switch j
                    case 1
                        F_applied_temp = F_max_temp;
                    case 2
                        F_applied_temp = 1.0393*Y_temp(:,2).^2/10^4+0.0142 + 9.80665*(gd(i));
                    case 3
                        F_applied_temp = 0 * Y_temp(:,2);
                    case 4
                        F_applied_temp = -B_max_temp;
                end;
                F_max = [F_max; F_max_temp];
                B_max = [B_max; B_max_temp];
                F_applied = [F_applied; F_applied_temp];
            end;
        end;
    end;
    energy_consumption_simulation=[energy_consumption_simulation;Y(end,3)];
    T=T(2:end,:);
    Y=Y(2:end,:);
    
    subplot(2,1,1);
    plot(Y(:,1), Y(:,2), 'b-');
    hold on;
    xlim([0, subsection_list(end,2)]);
    
    subplot(2,1,2);
    plot(Y(:,1), 278*F_max, 'k:');
    hold on;
    plot(Y(:,1), -278*B_max, 'k:');
    hold on;
    plot(Y(:,1), 278*F_applied, 'b-');
    hold on;
    xlim([0, subsection_list(end,2)]);
    ylabel('Forces');
    xlabel('Location');

end;

energy_consumption_simulation;

subplot(2,1,1);
sl_plot=[];
for i=1:size(sl_table,1)-1
    sl_plot=[sl_plot; [sl_table(i,3),sl_table(i,2); sl_table(i,4),sl_table(i,2)]];
end;
p2=plot(sl_plot(:,1),sl_plot(:,2),'k--');

gd_table=[ones(size(subsection_list,1),1),subsection_list(:,[3,1,2])];
x0=0;
y0=0;
gd_vector=[x0,y0];
for i=1:size(gd_table,1)
    x0=x0+gd_table(i,4)-gd_table(i,3);
    y0=y0+1*(gd_table(i,4)-gd_table(i,3))*gd_table(i,2);
    gd_vector=[gd_vector;[x0,y0]];
end
gd_vector=[gd_vector(:,1), 5.5+0.25*gd_vector(:,2)];
gd_vector=[gd_vector; [gd_vector(end,1),0]; [0,0]; gd_vector(1,:)];
plot(gd_vector(:,1),gd_vector(:,2),'k-','linewidth',0.5);

set(gca,'FontName','Times','FontSize',12,'XTick',[0 2631 3905 6271 8254 9246 10785 12065 13419 15756 18021 20107 21394 22728],'XTickLabel', {'SJ', 'XC', 'XH', 'JG', 'YZQ', 'WH', 'WY', 'RJ', 'RC', 'TJ', 'JH', 'CQN', 'CQ', 'YZ'});
ylim([0,25]);
xlabel('Location', 'FontSize',12,'FontName','Times');
ylabel('Speed (m/s)', 'FontSize',12,'FontName','Times');

subplot(2,1,2);
set(gca,'FontName','Times','FontSize',12,'XTick',[0 2631 3905 6271 8254 9246 10785 12065 13419 15756 18021 20107 21394 22728],'XTickLabel', {'SJ', 'XC', 'XH', 'JG', 'YZQ', 'WH', 'WY', 'RJ', 'RC', 'TJ', 'JH', 'CQN', 'CQ', 'YZ'});
xlabel('Location', 'FontSize',12);
ylabel('Forces (kN)', 'FontSize',12);