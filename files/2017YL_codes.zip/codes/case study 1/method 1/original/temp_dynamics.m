function dx=temp_dynamics(t,x,y)

global subsection_list;
x(1)=max(0,min(x(1), subsection_list(end,2)));
gd=subsection_list(find(subsection_list(:,1)<=x(1) & subsection_list(:,2)>=x(1)),3);
dx=zeros(3,1);
switch y
    case 1
        dx(1) = x(2);
        dx(2) = min(310,310-5*(3.6*x(2)-36))/278 - (1.0393*x(2)^2/10^4+0.0142) - 9.80665*(gd);
        dx(3) = min(310/278, 490/278-18/278*x(2))*x(2);
    case 2
        dx(1) = x(2);
        dx(2) = 0;
        dx(3) = max(0,(1.0393*x(2)^2/10^4+0.0142) + 9.80665*(gd))*x(2);
    case 3
        dx(1) = x(2);
        dx(2) = 0 - (1.0393*x(2)^2/10^4+0.0142) - 9.80665*(gd);
        dx(3) = 0;
    case 4
        dx(1) = x(2);
        dx(2) = -min(260,260-5*(3.6*x(2)-60))/278 - (1.0393*x(2)^2/10^4+0.0142) - 9.80665*(gd);
        dx(3) = 0;
end;
