global sl_table;
global gd_table;
global phase_num;

figure;
subplot(2,1,1);
for iphase=1:length(solution)
    p1=plot(solution(iphase).state(:,1),solution(iphase).state(:,2),'-b','LineWidth',1);
    hold on;
end;

for i=1:size(sl_table,1)
    p2=plot([sl_table(i,3),sl_table(i,4)],[sl_table(i,2),sl_table(i,2)],':k','LineWidth',1);
    hold on;
end
for i=1:size(sl_table,1)-1
    p2=plot([sl_table(i,4),sl_table(i,4)],[sl_table(i,2),sl_table(i+1,2)],':k','LineWidth',1);
    hold on;
end

x0=0;
y0=0;
gd_vector=[x0,y0];
for i=1:size(gd_table,1)
    x0=x0+gd_table(i,4)-gd_table(i,3);
    y0=y0+1*(gd_table(i,4)-gd_table(i,3))*gd_table(i,2);
    gd_vector=[gd_vector;[x0,y0]];
end
gd_vector=[gd_vector(:,1), 5.5+0.25*gd_vector(:,2)];
gd_vector=[gd_vector; [gd_vector(end,1),0]; [0,0]; gd_vector(1,:)];
plot(gd_vector(:,1),gd_vector(:,2),'k-','linewidth',1);
% gd_area=[gd_vector; [gd_vector(end,1), 0]; [gd_vector(1,1),0]];
% fill(gd_area(:,1), gd_area(:,2), 'k','edgecolor','none','facealpha', 0.1);

set(gca,'FontName','Times','FontSize',12,'XTick',[0 2631 3905 6271 8254 9246 10785 12065 13419 15756 18021 20107 21394 22728],'XTickLabel', {'SJ', 'XC', 'XH', 'JG', 'YZQ', 'WH', 'WY', 'RJ', 'RC', 'TJ', 'JH', 'CQN', 'CQ', 'YZ'});
xlim([0, solution(phase_num).state(end,1)]);
ylim([0,25]);
xlabel('Location (m)', 'FontSize',12, 'FontName', 'Times');
ylabel('Speed (m/s)', 'FontSize',12, 'FontName', 'Times');
legend([p2, p1], 'Speed Limit','Speed');

subplot(2,1,2);
F_all=[];
B_all=[];
Location_all=[];
Speed_all=[];
for iphase=1:length(solution)    
    Location_all=[Location_all;solution(iphase).state(:,1)];
    Speed_all=[Speed_all; solution(iphase).state(:,2)];
    F_all=[F_all; solution(iphase).control(:,1)];
    B_all=[B_all; -solution(iphase).control(:,2)];
end;

plot(Location_all, F_all,'b-');
hold on;
plot(Location_all, B_all, 'r-');
hold on;
plot(Location_all, min(310, 310-5*(3.6*Speed_all-36)), '--k');
hold on;
plot(Location_all, -min(260, 260-5*(3.6*Speed_all-60)), ':k');
hold on;

set(gca,'FontName','Times','FontSize',12, 'FontName', 'Times');
xlabel('Location (m)', 'FontSize',12, 'FontName', 'Times');
ylabel('Forces (kN)', 'FontSize',12, 'FontName', 'Times');
legend('Tractive','Braking');
set(gca,'FontName','Times','FontSize',12,'XTick',[0 2631 3905 6271 8254 9246 10785 12065 13419 15756 18021 20107 21394 22728],'XTickLabel', {'SJ', 'XC', 'XH', 'JG', 'YZQ', 'WH', 'WY', 'RJ', 'RC', 'TJ', 'JH', 'CQN', 'CQ', 'YZ'});
xlim([0, solution(phase_num).state(end,1)]);
