clear
clc

train_network_yizhuang

tic
NLP_epsilon=[1e-10, 1e-10];
colpoints_num=40;
meshpoint_num=1;
mesh_iteration=0;

global phase_num;
global subsection_num;
global subsection_list;

subsection_list=[	   0     150    -0.002	13.89
					 150     160    -0.002	23.61
					 160     470    -0.003	23.61
					 470     480     0.0104	23.61
					 480     970     0.0104	18.06
					 970    1161	 0.003	18.06
					1161	1370 	 0.003	23.61
					1370	1880	-0.008	23.61
					1880	2500	 0.003	23.61
					2500	2501	-0.002	23.61
					2501	2643	-0.002	16.67
					2643	2770	-0.002	23.61
					2770	2797	-0.003	23.61
					2797	3170	-0.003	20.83
					3170	3534	 0.0082	20.83
					3534	3570	 0.0082	23.61
					3570	3780	 0.002	23.61
					3780	3918	 0.002	16.67
					3918	3940	 0.002	23.61
					3940	4200	-0.0204	23.61
					4200	4800	-0.024	23.61
					4800	5200	 0      23.61
					5200	5800	-0.002	23.61
					5800	5808	-0.0032	23.61
					5808	6050	-0.0032	20.83
					6050	6141	 0      20.83
					6141	6271	 0      16.67];

subsection_num=size(subsection_list,1);
sl=subsection_list(:,4)';
gd=subsection_list(:,3)';
section_length=[subsection_list(:,2)-subsection_list(:,1)]';
total_running_time=370;
current_speed = 0;
min_sub_running_time=section_length./sl;

phase_num=subsection_num;
for iphase=1:phase_num
    if iphase==1
        limits(iphase).time.min = [0,sum(min_sub_running_time(1:iphase))];
        limits(iphase).time.max = [0, total_running_time-sum(min_sub_running_time(iphase+1:subsection_num))];
    elseif iphase==phase_num
        limits(iphase).time.min = [sum(min_sub_running_time(1:iphase-1)),total_running_time];
        limits(iphase).time.max = [total_running_time-sum(min_sub_running_time(iphase:subsection_num)), total_running_time];
    else
        limits(iphase).time.min = [sum(min_sub_running_time(1:iphase-1)),sum(min_sub_running_time(1:iphase))];
        limits(iphase).time.max = [total_running_time-sum(min_sub_running_time(iphase:subsection_num)), total_running_time-sum(min_sub_running_time(iphase+1:subsection_num))];
    end;
    limits(iphase).state.min(1,:)   = [subsection_list(iphase,1), subsection_list(iphase,1), subsection_list(iphase,2)]; % location
    limits(iphase).state.max(1,:)   = [subsection_list(iphase,1), subsection_list(iphase,2), subsection_list(iphase,2)]; % location
    if iphase==1
        limits(iphase).state.min(2,:)   = [current_speed, 0, 0]; % speed
        limits(iphase).state.max(2,:)   = [current_speed, sl(iphase), min(sl(iphase:iphase+1))]; % speed
    elseif iphase==phase_num
        limits(iphase).state.min(2,:)   = [0, 0, 0]; % speed
        limits(iphase).state.max(2,:)   = [min(sl(iphase-1:iphase)), sl(iphase), 0]; % speed
    else
        limits(iphase).state.min(2,:)   = [0, 0, 0]; % speed
        limits(iphase).state.max(2,:)   = [min(sl(iphase-1:iphase)), sl(iphase), min(sl(iphase:iphase+1))]; % speed
    end
    
    limits(iphase).control.min = [0; 0];
    limits(iphase).control.max = [310; 260];
    limits(iphase).parameter.min    = [];
    limits(iphase).parameter.max    = [];
    limits(iphase).path.min    = [-310; -260];
    limits(iphase).path.max    = [0; 0];
    limits(iphase).duration.min = min_sub_running_time(iphase);
    limits(iphase).duration.max = total_running_time-sum(min_sub_running_time)+min_sub_running_time(iphase);
    limits(iphase).nodesPerInterval = colpoints_num;
end;
rand_temp=rand(1,subsection_num);
guess_running_time=min_sub_running_time+rand_temp./sum(rand_temp)*(total_running_time-sum(min_sub_running_time));
control_guess=[310*rand(1,subsection_num+1); 260*rand(1,subsection_num+1)];
for iphase=1:phase_num
    guess(iphase).time = [sum(guess_running_time(1:iphase-1)); sum(guess_running_time(1:iphase))];
    guess(iphase).state(:,1) = [subsection_list(iphase,1); subsection_list(iphase,2)];
    if iphase==1
        guess(iphase).state(:,2) = [ current_speed; rand*min(sl(iphase:iphase+1))];
    elseif iphase==phase_num
        guess(iphase).state(:,2) = [ guess(iphase-1).state(2,2); 0];
    else
        guess(iphase).state(:,2) = [ guess(iphase-1).state(2,2); rand*min(sl(iphase:iphase+1))];
    end;
    guess(iphase).control(:,1) = control_guess(:,iphase);
    guess(iphase).control(:,2) = control_guess(:,iphase+1);
    guess(iphase).parameter = [];
end;

for iphase=1:phase_num
    limits(iphase).meshPoints = [-1:2/meshpoint_num:1];
    limits(iphase).nodesPerInterval = colpoints_num*ones(1,meshpoint_num);
end

for ipair=1:phase_num-1
    linkages(ipair).left.phase = ipair;
    linkages(ipair).right.phase = ipair+1;
    linkages(ipair).min = [0; 0];
    linkages(ipair).max = [0; 0];
end;

setup.name = 'TrainScheduling';
setup.funcs.cost = 'TrainSchedulingCost';
setup.funcs.dae = 'TrainSchedulingDae';
setup.funcs.link = 'TrainSchedulingLink';
setup.limits = limits;
setup.derivatives = 'complex'; 
setup.guess = guess;
setup.linkages = linkages;
setup.autoscale = 'off';
setup.tolerances = NLP_epsilon;
setup.mesh.iteration = mesh_iteration;
setup.printoff = 0;

output = gpops(setup);
solution = output.solution;
toc
E=0;
for i=1:phase_num
    E=E+solution(i).Lagrange_cost;
end;
E/278 % kJ/kg
plotfigures;