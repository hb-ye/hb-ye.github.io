clear;
clc;

for subsection_length_max=[2000, 300, 200, 100]
    clearvars -except subsection_length_max
    
    global section_num;
    global sl;
    global gd;
    global subsection_length;
    global total_running_time;
    global current_speed;
    global subsection_list;
    
    TolX_val=1e-14;
    TolCon_val=1e-10;
    TolFun_val=1e-10;
    MaxIter_val=4000;
    MaxFunEvals_val=2000000;
    
    train_network_yizhuang
    
    %% cutting the max-length subsection plan based on subsection_length_max
    subsection_mark=[0; 150; 160; 470; 480; 970; 1161; 1370; 1880; 2500; 2501; 2643; 2770; 2797; 3170; 3534; 3570; 3780; 3918; 3940; 4200; 4800; 5200; 5800; 5808; 6050; 6141; 6271]; % endpoints of the max-length subsection plan
    subsection_mark_new=[];
    for i=1:length(subsection_mark)-1
        subsection_mark_new=[subsection_mark_new; subsection_mark(i,:)];
        subsection_length_i=subsection_mark(i+1)-subsection_mark(i);
        divide_num=ceil(subsection_length_i/subsection_length_max);
        if divide_num>1
            for k=1:divide_num-1
                subsection_mark_new=[subsection_mark_new; subsection_mark(i,:)+ k*subsection_length_i/divide_num];
            end;
        end;
    end;
    subsection_mark_new=[subsection_mark_new; subsection_mark(end)];
    subsection_mark=subsection_mark_new;
    
    subsection_list=[subsection_mark(1:end-1), subsection_mark(2:end)];
    for i=1:size(subsection_list,1)
        subsection_list(i,3)=gd_table(find(subsection_list(i,1)>=gd_table(:,3) & subsection_list(i,1)<=gd_table(:,4) & subsection_list(i,2)>=gd_table(:,3) & subsection_list(i,2)<=gd_table(:,4)),2);
        subsection_list(i,4)=sl_table(find(subsection_list(i,1)>=sl_table(:,3) & subsection_list(i,1)<=sl_table(:,4) & subsection_list(i,2)>=sl_table(:,3) & subsection_list(i,2)<=sl_table(:,4)),2);
    end;

    %%
    section_num=size(subsection_list,1);
    sl=subsection_list(:,4)';
    gd=subsection_list(:,3)';
    subsection_length=[subsection_list(:,2)-subsection_list(:,1)]';
    total_running_time=370;
    current_speed = 0;
    min_sub_running_time=subsection_length./sl;
    
    global a_r  b_r  c_r  a_max  a_min;
    a_r=1.0393/10^4;
    b_r=0;
    c_r=0.0142;
    a_max=310/278;
    a_min=260/278;
    
    trial_num=10;
    energy_consumption=zeros(trial_num,1);
    opt_result=zeros(trial_num, section_num*3);
    for xxx=1:trial_num
        nvars=3*section_num;
        LB=zeros(3*section_num,1);
        LB([1:3:3*section_num-2])=min_sub_running_time;
        LB([3:3:3*section_num])=-a_min;
        UB=zeros(3*section_num,1);
        UB([1:3:3*section_num-2])=total_running_time-sum(min_sub_running_time)+min_sub_running_time;
        UB([3:3:3*section_num])=a_max;
        for i=1:section_num
            if i~=section_num
                UB(3*i-1)=min(sl(i), sl(i+1));
            else
                UB(3*i-1)=0;
            end;
        end;
        Aeq=repmat([1,0,0], 1, section_num);
        beq=total_running_time;
        x0=zeros(1,nvars);
        x0_t=rand(1, section_num);
        x0_t=min_sub_running_time+x0_t./sum(x0_t)*(total_running_time-sum(min_sub_running_time));
        x0([1:3:3*section_num-2])=x0_t;
        for i=1:section_num
            if i~=section_num
                x0(1,(i-1)*3+2)=min(sl(i:i+1))*rand(1);
            else
                x0(1,(i-1)*3+2)=0;
            end;
        end;
        v_init=[current_speed, x0([2:3:3*section_num-1])];
        v_init=max([v_init(1:end-1); v_init(2:end)]);
        u_upper=min(310/278, 490/278-18/278*v_init);
        u_lower=-min(260/278,560/278-18/278*v_init);
        x0([3:3:3*section_num])=u_lower+(u_upper-u_lower).*rand(1,section_num);
        
        options_0=optimoptions('fmincon','Algorithm', 'interior-point', 'SubproblemAlgorithm', 'cg', 'Display', 'notify', 'TolX', TolX_val, 'TolCon', TolCon_val, 'TolFun', TolFun_val, 'MaxIter', MaxIter_val, 'MaxFunEvals', MaxFunEvals_val);
        options_opt = optimoptions('fmincon','Algorithm', 'interior-point', 'SubproblemAlgorithm', 'factorization', 'Display', 'notify', 'TolX', TolX_val, 'TolCon', TolCon_val, 'TolFun', TolFun_val, 'MaxIter', MaxIter_val, 'MaxFunEvals', MaxFunEvals_val);
        
        tic
        [x1,E1,exitflag,~] = fmincon(@(x)0,x0,[],[],Aeq,beq,LB,UB,@nonlcon_braking_curve_analytic,options_0);
        exit_flag_0(xxx,1)=exitflag;
        total_time_0(xxx,1)=toc;
        tic
        [x2,E2,exitflag,~] = fmincon(@energy_consumption_analytic,x1,[],[],Aeq,beq,LB,UB,@nonlcon_braking_curve_analytic,options_opt);
        total_time_opt(xxx,1)=toc;
        exit_flag_opt(xxx,1)=exitflag;
        total_time(xxx,1)=total_time_0(xxx,1)+total_time_opt(xxx,1);
        output=[x1; x2];
        E(xxx,:)=[E1,E2];
        energy_consumption(xxx)=E2;
        opt_result(xxx,:)=x2;
    end
    
    yyy=find(exit_flag_opt==2);
    trial_num-length(yyy)
    [max(total_time(yyy)), mean(total_time(yyy)), min(total_time(yyy))]
    [max(energy_consumption(yyy)), mean(energy_consumption(yyy)), min(energy_consumption(yyy))]
    exit_flag_opt(find(exit_flag_opt~=2))'
    
    save(strcat('method_2_', num2str(subsection_length_max)));
    temp_figure
end;