function dx=temp_dynamics(t,x,y)

dx=zeros(3,1);
dx(1) = x(2);
dx(2) = y(1) - (1.0393*x(2)^2/10^4+0.0142) - 9.80665*(y(2));
dx(3) = max(y(1),0)*x(2);
