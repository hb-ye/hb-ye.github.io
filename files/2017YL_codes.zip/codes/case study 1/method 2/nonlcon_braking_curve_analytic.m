function [c,ceq] = nonlcon_braking_curve_analytic(x)

global section_num;
global current_speed;
global gd;
global subsection_length;
global a_r  b_r  c_r;

ceq=[];
c=[];
t=x([1:3:3*section_num-2]);
v_f = x([2:3:3*section_num-1]);
u = x([3:3:3*section_num]);
ceq=zeros(2*section_num,1);
for i=1:section_num
    if i==1
        v_0 = current_speed;
    else
        v_0 = v_f(i-1);
    end;
    [s,v_f_temp] = solve_ode(-a_r,-b_r,u(i)-c_r-9.80665*(gd(i)),t(i),v_0);
    ceq(2*(i-1)+[1,2],1)=[v_f_temp-v_f(i); s-subsection_length(i)];
end;
c=[reshape(u-min(310,310-5*(3.6*v_0-36))/278,[],1); reshape(-u-min(260,260-5*(3.6*v_0-60))/278,[],1); reshape(u-min(310,310-5*(3.6*v_f-36))/278,[],1); reshape(-u-min(260,260-5*(3.6*v_f-60))/278,[],1)];
