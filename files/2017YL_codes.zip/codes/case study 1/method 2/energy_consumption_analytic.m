function E = energy_consumption_analytic(x)

global section_num;
global subsection_length;

u = x(3*[1:section_num]);
E = sum(max(u,0).*subsection_length);
