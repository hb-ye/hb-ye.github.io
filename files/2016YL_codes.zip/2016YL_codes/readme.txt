These are the MATLAB codes for case studies in "Ye, H., Liu, R., 2016. A multiphase optimal control method for multi-train control and scheduling on railway lines. Transportation Research Part B 93, 377-393."

The codes were tested on MATLAB 2020a in 64-bit Windows 10. The pseudospectral method is programmed based on GPOPS version 5.1.

To get the results, run 'TrainSchedulingMain.m' in each folder.
