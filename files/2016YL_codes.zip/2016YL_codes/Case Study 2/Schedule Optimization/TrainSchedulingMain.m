tic

train_network_yizhuang

global phase_num;
global station_location;
global running_time;
global total_running_time;
global current_running_time;

initial_guess_time=current_running_time;

for iphase=1:phase_num
    if iphase==1
        limits(iphase).time.min = [0, sum(running_time(1,1:iphase))];
        limits(iphase).time.max = [0, sum(running_time(2,1:iphase))];
    elseif iphase==phase_num
        limits(iphase).time.min = [sum(running_time(1,1:iphase-1)), total_running_time];
        limits(iphase).time.max = [sum(running_time(2,1:iphase-1)), total_running_time];
    else
        limits(iphase).time.min = [sum(running_time(1,1:iphase-1)), sum(running_time(1,1:iphase))];
        limits(iphase).time.max = [sum(running_time(2,1:iphase-1)), sum(running_time(2,1:iphase))];
    end;
    limits(iphase).state.min(1,:)   = [station_location(iphase), station_location(iphase), station_location(iphase+1)]; % location
    limits(iphase).state.max(1,:)   = [station_location(iphase), station_location(iphase+1), station_location(iphase+1)]; % location
    limits(iphase).state.min(2,:)   = [0 0 0]; % speed
    limits(iphase).state.max(2,:)   = [0 23.61 0]; % speed
    limits(iphase).control.min = [0; 0];
    limits(iphase).control.max = [310; 260];
    limits(iphase).parameter.min    = [];
    limits(iphase).parameter.max    = [];
    limits(iphase).path.min    = [-23.61; -310; -260];
    limits(iphase).path.max    = [0; 0; 0];
    limits(iphase).duration.min = running_time(1, iphase);
    limits(iphase).duration.max = running_time(2, iphase);
    
    guess(iphase).time = [sum(initial_guess_time(1,1:iphase-1)); sum(initial_guess_time(1,1:iphase))];
    guess(iphase).state(:,1) = [station_location(iphase); station_location(iphase+1)];
    guess(iphase).state(:,2) = [ 0; 0];
    guess(iphase).control(:,1) = [ 310; 0];
    guess(iphase).control(:,2) = [ 0; 260];
    guess(iphase).parameter = [];
end;

mesh_num=1;
colpoints_num=100*ones(1,13);
for iphase=1:phase_num
    limits(iphase).meshPoints = [-1:2/mesh_num:1];
    limits(iphase).nodesPerInterval = colpoints_num(iphase)*ones(1,mesh_num);
end

for ipair=1:phase_num-1
    linkages(ipair).left.phase = ipair;
    linkages(ipair).right.phase = ipair+1;
    linkages(ipair).min = [0];
    linkages(ipair).max = [0];
end;

setup.name = 'TrainScheduling';
setup.funcs.cost = 'TrainSchedulingCost';
setup.funcs.dae = 'TrainSchedulingDae';
setup.funcs.link = 'TrainSchedulingLink';
setup.limits = limits;
setup.guess = guess; 
setup.linkages = linkages;

setup.derivatives = 'complex';
setup.autoscale = 'off';
setup.tolerances = [4.7e-4, 3.1e-5];
setup.mesh.iteration = 0; % 10 by default
%setup.mesh.tolerance = 1e-5;
%setup.mesh.maxIterations=20;
%setup.mesh.nodesPerInterval.min = 4; % 4 by default
%setup.mesh.nodesPerInterval.max = 10; % 12 by default
setup.printoff = 0;

output = gpops(setup);
toc;
solution = output.solution;
for iphase=1:length(solution)
    running_time_opt(iphase) = solution(iphase).time(end)-solution(iphase).time(1);
end;
running_time_opt'

%--------------------------------%
% End File:  TrainSchedulingMain.m %
%--------------------------------%
