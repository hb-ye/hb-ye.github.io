function link = TrainSchedulingLink(sol)

link = [0];

%--------------------------------%
% End File:  TrainSchedulingLink.m %
%--------------------------------%