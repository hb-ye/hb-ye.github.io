function gd = gradient_profile(x) %%% a function that outputs the gradient of location x %%%
global gd_table;
gd=x;
x=min(max(0,x),22728);
for i=1:length(x)
    a=find(gd_table(:,3)<=x(i) & gd_table(:,4)>=x(i));
    gd(i)=gd_table(a(1), 2);
end;