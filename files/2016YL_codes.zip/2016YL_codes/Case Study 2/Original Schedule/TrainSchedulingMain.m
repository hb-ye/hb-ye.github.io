tic

train_network_yizhuang

global phase_num;
global station_location;
global running_time;
global current_departure;
global current_arrival;

colpoints_num=140*ones(1,13);
colpoints_num(9)=60;
colpoints_num(13)=80;
colpoints_num(5)=100;
colpoints_num(1)=150;
colpoints_num(4)=190;
colpoints_num(10)=190;

for iphase=1:phase_num
    if iphase==1
        limits.time.min = [current_departure(1), sum(running_time(1,1:iphase))];
        limits.time.max = [current_departure(1), sum(running_time(2,1:iphase))];
    elseif iphase==phase_num
        limits.time.min = [sum(running_time(1,1:iphase-1)), current_arrival(phase_num)];
        limits.time.max = [sum(running_time(2,1:iphase-1)), current_arrival(phase_num)];
    else
        limits.time.min = [sum(running_time(1,1:iphase-1)), sum(running_time(1,1:iphase))];
        limits.time.max = [sum(running_time(2,1:iphase-1)), sum(running_time(2,1:iphase))];
    end;
    limits.state.min(1,:)   = [station_location(iphase), station_location(iphase), station_location(iphase+1)]; % location
    limits.state.max(1,:)   = [station_location(iphase), station_location(iphase+1), station_location(iphase+1)]; % location
    limits.state.min(2,:)   = [0 0 0]; % speed
    limits.state.max(2,:)   = [0 23.61 0]; % speed
    limits.control.min = [0; 0];
    limits.control.max = [310; 260];
    limits.parameter.min    = [];
    limits.parameter.max    = [];
    limits.path.min    = [-23.61; -310; -260];
    limits.path.max    = [0; 0; 0];
    limits.duration.min = running_time(1, iphase);
    limits.duration.max = running_time(2, iphase);
    
    guess.time = [current_departure(iphase); current_arrival(iphase)];
    guess.state(:,1) = [station_location(iphase); station_location(iphase+1)];
    guess.state(:,2) = [ 0; 0];
    guess.control(:,1) = [ 310; 0];
    guess.control(:,2) = [ 0; 260];
    guess.parameter = [];

    mesh_num=1;
    limits.meshPoints = [-1:2/mesh_num:1];
    limits.nodesPerInterval = colpoints_num(iphase);
    
    setup.name = 'TrainScheduling';
    setup.funcs.cost = 'TrainSchedulingCost';
    setup.funcs.dae = 'TrainSchedulingDae';
    setup.limits = limits;
    setup.guess = guess;

    setup.derivatives = 'complex';
    setup.autoscale = 'off';
    setup.tolerances = [2e-6, 5e-12];
    setup.mesh.iteration = 0;
    %setup.mesh.tolerance = 1e-5;
    %setup.mesh.maxIterations=20;
    %setup.mesh.nodesPerInterval.min = 4; % 4 by default
    %setup.mesh.nodesPerInterval.max = 10; % 12 by default
    
    setup.printoff = 0;
    
    output = gpops(setup);
    solution(iphase) = output.solution;
    energy_consumption(iphase) = solution(iphase).Lagrange_cost;
end;

total_energy_consumption = sum(energy_consumption)

toc

plotfigures_whole_line;
plotfigures_sections;

%--------------------------------%
% End File:  TrainSchedulingMain.m %
%--------------------------------%
