%%% visualize the result for particular sections %%%

global sl_table;
global gd_table;

figure;

for xx=1:3
    subplot(2,3,xx);
    for iphase=1:length(solution)
        p1=plot(solution(iphase).state(:,1),solution(iphase).state(:,2),'-b','LineWidth',1);
        hold on;
    end;
    
    for i=1:size(sl_table,1)
        p2=plot([sl_table(i,3),sl_table(i,4)],[sl_table(i,2),sl_table(i,2)],':k','LineWidth',1);
        hold on;
    end
    for i=1:size(sl_table,1)-1
        p2=plot([sl_table(i,4),sl_table(i,4)],[sl_table(i,2),sl_table(i+1,2)],':k','LineWidth',1);
        hold on;
    end
    
    x0=0;
    y0=0;
    gd_vector=[x0,y0];
    for i=1:size(gd_table,1)
        x0=x0+gd_table(i,4)-gd_table(i,3);
        y0=y0+1*(gd_table(i,4)-gd_table(i,3))*gd_table(i,2);
        gd_vector=[gd_vector;[x0,y0]];
    end
    gd_vector=[gd_vector(:,1), 6+0.3*gd_vector(:,2)];
    plot(gd_vector(:,1),gd_vector(:,2),'k-','linewidth',1);
    
    set(gca,'FontName','Times','FontSize',12,'XTick',[0 2631 3905 6271 8254 9246 10785 12065 13419 15756 18021 20107 21394 22728],'XTickLabel', {'SJ', 'XC', 'XH', 'JG', 'YZQ', 'WH', 'WY', 'RJ', 'RC', 'TJ', 'JH', 'CQN', 'CQ', 'YZ'});
    xlim([0,station_location(length(solution)+1)]);
    ylim([0,25]);
    xlabel('Location', 'FontSize',12);
    ylabel('Speed (m/s)', 'FontSize',12);
    
    subplot(2,3,xx+3);
    for iphase=1:length(solution)
        plot(solution(iphase).state(:,1), min(310, 310-5*(3.6*solution(iphase).state(:,2)-36)), '--k');
        hold on;
        plot(solution(iphase).state(:,1), -min(260, 260-5*(3.6*solution(iphase).state(:,2)-60)), '--k');
        hold on;
        pp = plot(solution(iphase).state(:,1),solution(iphase).control(:,1),'-r','LineWidth',1);
        hold on;
        pp = plot(solution(iphase).state(:,1),-solution(iphase).control(:,2),':b','LineWidth',1);
        hold on;
    end;
    set(gca,'FontName','Times','FontSize',12);
    xlabel('Location', 'FontSize',12);
    ylabel('Forces (kN)', 'FontSize',12);
    set(gca,'XTick',[0 2631 3905 6271 8254 9246 10785 12065 13419 15756 18021 20107 21394 22728],'XTickLabel', {'SJ', 'XC', 'XH', 'JG', 'YZQ', 'WH', 'WY', 'RJ', 'RC', 'TJ', 'JH', 'CQN', 'CQ', 'YZ'});
    xlim([0,station_location(length(solution)+1)]);
end;
subplot(2,3,1);
xlim([station_location(1),station_location(2)]);
subplot(2,3,4);
xlim([station_location(1),station_location(2)]);
subplot(2,3,2);
xlim([station_location(11),station_location(12)]);
subplot(2,3,5);
xlim([station_location(11),station_location(12)]);
subplot(2,3,3);
xlim([station_location(13),station_location(14)]);
subplot(2,3,6);
xlim([station_location(13),station_location(14)]);
