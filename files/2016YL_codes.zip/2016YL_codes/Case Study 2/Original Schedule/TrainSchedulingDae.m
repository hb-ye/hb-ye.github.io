function dae = TrainSchedulingDae(sol)

t = sol.time;
y = sol.state;
force = sol.control; % forces are the control variables
x = y(:,1); % location
v = y(:,2); % speed
xdot = v;
vdot = (force(:,1)-force(:,2))/278-(1.0393*v.^2/10^4+0.0142)-9.80665*sin(gradient_profile(x)); % tractive/braking: N; resistance: N/kg
path=[v-speed_limit(x), force(:,1)-min(310, 310-5*(3.6*v-36)), force(:,2)-min(260, 260-5*(3.6*v-60))];
dae = [xdot vdot path];

%-------------------------------%
% End File:  TrainSchedulingDae.m %
%-------------------------------%