tic

global safety_distance; 
global station_location; 
global B_max; 
global F_max;
global F_max_malfun;
global v1_max;
global v2_max;
global current_arrival;
global malfun_happen_time;
global malfun_happen_location;
global malfun_happen_speed;

train_network_3_stations

% Phase 1
iphase=1;
limits(iphase).time.min = [malfun_happen_time, malfun_happen_time+(station_location(2)-malfun_happen_location(1))/v1_max];
limits(iphase).time.max = [malfun_happen_time, current_arrival(2)-(station_location(3)-station_location(2)+safety_distance)/v2_max];
limits(iphase).state.min   = [  malfun_happen_location(1),	malfun_happen_location(1),	station_location(2);
                                malfun_happen_location(2),	malfun_happen_location(2),	malfun_happen_location(2);
                                malfun_happen_speed(1),	0,	0;
                                malfun_happen_speed(2),	0,	0];
limits(iphase).state.max   = [	malfun_happen_location(1),	station_location(2),	station_location(2);
                                malfun_happen_location(2),	station_location(2)-safety_distance,	station_location(2)-safety_distance;
                                malfun_happen_speed(1),	v1_max,	0;
                                malfun_happen_speed(2),	v2_max,	v2_max];
limits(iphase).control.min = [0; 0; 0; 0]; % control = [tractive of train 1, braking of train 1, tractive of train 2, braking of train 2]
limits(iphase).control.max = [F_max_malfun; B_max; F_max; B_max];
limits(iphase).parameter.min    = [];
limits(iphase).parameter.max    = [];
limits(iphase).path.min    = [-F_max_malfun; -B_max; -F_max; -B_max; safety_distance];
limits(iphase).path.max    = [0; 0; 0; 0; station_location(2)-malfun_happen_location(2)];
limits(iphase).duration.min = (station_location(2)-malfun_happen_location(1))/v1_max;
limits(iphase).duration.max = current_arrival(2)-(station_location(3)-station_location(2)+safety_distance)/v2_max-malfun_happen_time;
guess(iphase).time = [malfun_happen_time; malfun_happen_time+(station_location(2)-malfun_happen_location(1))/v1_max];
guess(iphase).state = [ malfun_happen_location, malfun_happen_speed;
                        station_location(2), station_location(2)-safety_distance, 0, v2_max];
guess(iphase).control = [F_max_malfun, 0, 110, 0;
                         0, B_max, 76, 0];
guess(iphase).parameter = [];


% Phase 2
iphase=iphase+1;
limits(iphase).time.min = [malfun_happen_time+(station_location(2)-malfun_happen_location(1))/v1_max, malfun_happen_time+(station_location(2)+safety_distance-malfun_happen_location(2))/v2_max];
limits(iphase).time.max = [current_arrival(2)-(station_location(3)-station_location(2)+safety_distance)/v2_max, current_arrival(1)-(station_location(3)-station_location(2))/v1_max];
limits(iphase).state.min   = [  station_location(2),	station_location(2),	station_location(2);
                                malfun_happen_location(2),	malfun_happen_location(2),	station_location(2)+safety_distance;
                                0,	0,	0;
                                0,	0,	0];
limits(iphase).state.max   = [  station_location(2),	station_location(2),	station_location(2);
                                station_location(2)-safety_distance,	station_location(3),	station_location(3);
                                0,	0,	0;
                                v2_max,	v2_max,	v2_max];
limits(iphase).control.min = [0; 0; 0; 0];
limits(iphase).control.max = [0; 0; F_max; B_max];
limits(iphase).parameter.min    = [];
limits(iphase).parameter.max    = [];
limits(iphase).path.min    = [-F_max; -B_max];
limits(iphase).path.max    = [0; 0];
limits(iphase).duration.min = 2*safety_distance/v2_max;
limits(iphase).duration.max= (current_arrival(1)-(station_location(3)-station_location(2))/v1_max)-(malfun_happen_time+(station_location(2)-malfun_happen_location(1))/v1_max);
guess(iphase).time = [malfun_happen_time+(station_location(2)-safety_distance-malfun_happen_location(2))/v2_max; malfun_happen_time+(station_location(2)+safety_distance-malfun_happen_location(2))/v2_max];
guess(iphase).state = [ station_location(2), station_location(2)-safety_distance, 0, v2_max;
                        station_location(2), station_location(2)+safety_distance, 0, v2_max];
guess(iphase).control = [0, 0, 0, 0;
                         0, 0, 0, 0];
guess(iphase).parameter = [];


% Phase 3
iphase=iphase+1; 
limits(iphase).time.min = [malfun_happen_time+(station_location(2)+safety_distance-malfun_happen_location(2))/v2_max, current_arrival(2)];
limits(iphase).time.max = [current_arrival(2), current_arrival(2)];
limits(iphase).state.min   = [  station_location(2),	station_location(2),	station_location(2);
                                station_location(2)+safety_distance,    station_location(2)+safety_distance,	station_location(3);
                                0,	0,	0;
                                0,	0,	0];
limits(iphase).state.max   = [  station_location(2),	station_location(3)-safety_distance,    station_location(3)-safety_distance;
                                station_location(3),    station_location(3),    station_location(3);
                                0,	v1_max,	v1_max;
                                v2_max,	v2_max,	0];
limits(iphase).control.min = [0; 0; 0; 0];
limits(iphase).control.max = [F_max_malfun; B_max; F_max; B_max];
limits(iphase).parameter.min    = [];
limits(iphase).parameter.max    = [];
limits(iphase).path.min    = [-F_max_malfun; -B_max; -F_max; -B_max; safety_distance];
limits(iphase).path.max    = [0; 0; 0; 0; station_location(3)-station_location(2)];
limits(iphase).duration.min = 0;
limits(iphase).duration.max= current_arrival(2)-malfun_happen_time;
guess(iphase).time = [malfun_happen_time+(station_location(2)+safety_distance-malfun_happen_location(2))/v2_max; malfun_happen_time+(station_location(3)-malfun_happen_location(2))/v2_max];
guess(iphase).state = [ station_location(2), station_location(2)+safety_distance, 0, v2_max;
                        station_location(3)-safety_distance, station_location(3), v1_max, 0];
guess(iphase).control = [F_max_malfun, 0, 0, 0;
                         0, 0, 0, B_max];
guess(iphase).parameter = [];


% Phase 4
iphase=iphase+1; 
limits(iphase).time.min = [current_arrival(2), current_arrival(1)];
limits(iphase).time.max = [current_arrival(2), current_arrival(1)];
limits(iphase).state.min   = [  station_location(2),	station_location(2),	station_location(3);
                                station_location(3),	station_location(3),	station_location(3);
                                0,	0,	0;
                                0,	0,	0];
limits(iphase).state.max   = [  station_location(3)-safety_distance,	station_location(3),	station_location(3);
                                station_location(3),	station_location(3),	station_location(3);
                                v1_max,	v1_max,	0;
                                0,	0,	0];
limits(iphase).control.min = [0; 0; 0; 0];
limits(iphase).control.max = [F_max_malfun; B_max; 0; 0];
limits(iphase).parameter.min    = [];
limits(iphase).parameter.max    = [];
limits(iphase).path.min    = [-F_max_malfun; -B_max];
limits(iphase).path.max    = [0; 0];
limits(iphase).duration.min = current_arrival(1)-current_arrival(2);
limits(iphase).duration.max = current_arrival(1)-current_arrival(2);
guess(iphase).time = [ malfun_happen_time+(station_location(3)-malfun_happen_location(2))/v2_max; malfun_happen_time+(station_location(3)-malfun_happen_location(2))/v2_max+safety_distance/v1_max];
guess(iphase).state = [ station_location(3)-safety_distance, station_location(3), v1_max, 0;
                        station_location(3), station_location(3), 0, 0];
guess(iphase).control = [0, 0, 0, 0;
                         0, B_max, 0, 0];
guess(iphase).parameter = [];


colpoints_num=[110, 110, 230, 100];
meshpoint_num=1;
for iphase=1:phase_num
    limits(iphase).meshPoints = [-1:2/meshpoint_num:1];
    limits(iphase).nodesPerInterval = colpoints_num(iphase)*ones(1,meshpoint_num);
end
    
for ipair=1:phase_num-1
    linkages(ipair).left.phase = ipair;
    linkages(ipair).right.phase = ipair+1;
    linkages(ipair).min = zeros(4,1);
    linkages(ipair).max = zeros(4,1);
end;

setup.name = 'TrainScheduling';
setup.funcs.cost = 'TrainSchedulingCost';
setup.funcs.dae = 'TrainSchedulingDae';
setup.funcs.link = 'TrainSchedulingLink';
setup.limits = limits;
setup.guess = guess; 
setup.linkages = linkages;

setup.autoscale = 'off';
setup.derivatives = 'complex';
setup.tolerances = [6.3e-3, 1.2e-4];
setup.mesh.iteration = 0;
%setup.mesh.tolerance = 1e-2;
%setup.mesh.maxIterations=20;
%setup.mesh.nodesPerInterval.min = 4;
%setup.mesh.nodesPerInterval.max = 12;
setup.printoff = 0;

[output,gpopsHistory] = gpops(setup);

toc

plotfigures;

%--------------------------------%
% End File:  TrainSchedulingMain.m %
%--------------------------------%
