function [Mayer,Lagrange]=TrainSchedulingCost(sol)

x  = sol.state; % [location of train 1, location of train 2, speed of train 1, speed of train 2]
u  = sol.control; % [tractive of train 1, braking of train 1, tractive of train 2, braking of train 2]
Lagrange =  x(:,3).*u(:,1)+x(:,4).*u(:,3);
Mayer    =  0; 

%--------------------------------%
% End File:  TrainSchedulingCost.m %
%--------------------------------%

