%%% parameters of the line and train %%%

global phase_num; 
global safety_distance; 
global station_location; 
global B_max; 
global F_max;
global F_max_malfun;
global v1_max;
global v2_max;
global gd_table;
global malfun_happen_time;
global malfun_happen_location;
global malfun_happen_speed;
global current_arrival;

phase_num=4;
current_arrival=[50*60, 45*60]; % scheduled arrival time; in second
station_location=[0 40000 80000]; % in meter
B_max=200; % upper bound of braking force; in kN
F_max=140; % upper bound of tractive force; in kN
F_max_malfun=70; % upper bound of tractive force after malfunction; in kN
v1_max=50; % speed limit for train 1; in m/s
v2_max=50; % speed limit for train 2; in m/s
malfun_happen_time=10*60; % in second
malfun_happen_location=[19144, 7611]; % in meter 
malfun_happen_speed=[35.4, 33.1]; % in m/s
safety_distance=2000; % in meter

% gradient
gd_table=[	 0.0	   0	2284
			-4.2	2284	3871
			 2.0	3871	6094
			16.7	6094	8181
			 0.0	8181	10323
			 1.7	10323	13750
			 0.0	13750	15711
			13.3	15711	19314
			 0.0	19314	21222
			-5.6	21222	23609
			-8.3	23609	27504
			-3.3	27504   30127	
			-8.3	30127	32778
			-2.5	32778	36003
			 0.0	36003	38091
			 0.5	38091	40000];
gd_table(:,1)=gd_table(:,1)/1000;
gd_table=[gd_table; [gd_table(:,1), gd_table(:,2:3)+40000]];
