function link = TrainSchedulingLink(sol)

xf_left = sol.left.state;
x0_right = sol.right.state;

link = [x0_right-xf_left];

%--------------------------------%
% End File:  TrainSchedulingLink.m %
%--------------------------------%