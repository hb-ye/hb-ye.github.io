%%% visualize the result %%%

solution = output.solution;

figure;
subplot(4,1,1);
for iphase=1:length(solution)
    p1 = plot(solution(iphase).time,solution(iphase).state(:,1)/1000,'-b');
    hold on;
    p2 = plot(solution(iphase).time,solution(iphase).state(:,2)/1000,'--r');
    hold on;
end;
set(gca,'XTick',[malfun_happen_time:300:current_arrival(1)],'XTickLabel',{'8:10','8:15','8:20','8:25','8:30','8:35', '8:40','8:45','8:50','8:55'});
set(gca,'fontsize',12);
xlabel('Time','fontsize',12);
ylabel('Location (km)','fontsize',12);
xlim([malfun_happen_time,current_arrival(1)]);
ylim([station_location(1),station_location(3)]/1000);
legend([p1,p2],'Train 1','Train 2');

subplot(4,1,2);
p_sl = plot([malfun_happen_time,current_arrival(1)], 3.6*[v1_max,v1_max],':k');
hold on;
for iphase=1:length(solution)
    p1 = plot(solution(iphase).time, 3.6*solution(iphase).state(:,3),'-b');
    hold on;
    p2 = plot(solution(iphase).time, 3.6*solution(iphase).state(:,4),'--r');
    hold on;
end;
set(gca,'XTick',[malfun_happen_time:300:current_arrival(1)],'XTickLabel',{'8:10','8:15','8:20','8:25','8:30','8:35', '8:40','8:45','8:50','8:55'});
set(gca,'fontsize',12);
xlabel('Time','fontsize',12);
ylabel('Speed (km/h)','fontsize',12);
xlim([malfun_happen_time,current_arrival(1)]);
legend([p_sl,p1,p2],'Speed limit', 'Train 1', 'Train 2');

subplot(4,1,3);
for iphase=1:length(solution)
    p1 = plot(solution(iphase).time, solution(iphase).control(:,1),'r-', 'linewidth', 1);
    p1.Color(4) = 0.5;
    hold on;
    p2 = plot(solution(iphase).time, -solution(iphase).control(:,2),'b-.', 'linewidth', 1);
    hold on;
    p3 = plot(solution(iphase).time, min(70, 70-0.9*(3.6*solution(iphase).state(:,3)-90)),'--k', 'linewidth', 0.5);
    hold on;
    p4 = plot(solution(iphase).time, -min(200, 200-0.8*(3.6*solution(iphase).state(:,3)-60)),':k', 'linewidth', 0.5);
    hold on;
end;
set(gca,'XTick',[malfun_happen_time:300:current_arrival(1)],'XTickLabel',{'8:10','8:15','8:20','8:25','8:30','8:35', '8:40','8:45','8:50','8:55'});
set(gca,'fontsize',12);
xlabel('Time','fontsize',12);
ylabel('Train 1 Forces (kN)','fontsize',12);
xlim([malfun_happen_time,current_arrival(1)]);
ylim([-200,100]);
legend([p1,p2,p3,p4],'$F$','$-B$','$\hat{F}(v)$', '$-\bar{B}(v)$', 'Interpreter','latex');

subplot(4,1,4);
for iphase=1:length(solution)
    p1 = plot(solution(iphase).time, solution(iphase).control(:,3),'r-', 'linewidth',1);
    p1.Color(4) = 0.5;
    hold on;
    p2 = plot(solution(iphase).time, -solution(iphase).control(:,4),'b-.', 'linewidth',1);
    hold on;
    p3 = plot(solution(iphase).time, min(140, 140-0.9*(3.6*solution(iphase).state(:,4)-90)),'--k', 'linewidth', 0.5);
    hold on;
    p4 = plot(solution(iphase).time, -min(200, 200-0.8*(3.6*solution(iphase).state(:,4)-60)),':k', 'linewidth', 0.5);
    hold on;
end;
set(gca,'XTick',[malfun_happen_time:300:current_arrival(1)],'XTickLabel',{'8:10','8:15','8:20','8:25','8:30','8:35', '8:40','8:45','8:50','8:55'});
set(gca,'fontsize',12);
xlabel('Time','fontsize',12);
ylabel('Train 2 Forces (kN)','fontsize',12);
xlim([malfun_happen_time,current_arrival(1)]);
ylim([-200,150]);
legend([p1,p2,p3,p4],'$F$','$-B$','$\bar{F}(v)$', '$-\bar{B}(v)$', 'Interpreter','latex');

