function dae = TrainSchedulingDae(sol)

global F_max;
global B_max;
global F_max_malfun;

t = sol.time;
y = sol.state;
force = sol.control; % forces are the control variables; force = [tractive of train 1, braking of train 1, tractive of train 2, braking of train 2]
p = sol.phase;

x = y(:,1:2); % locations of train 1 and train 2
v = y(:,3:4); % speeds of train 1 and train 2

if p==2 % phase 2 
    xdot = [zeros(length(t),1), v(:,2)]; % train 1 stopping at node 2
    vdot = [zeros(length(t),1), (force(:,3)-force(:,4)-(0.01644624*v(:,2).^2+0.3636*v(:,2)+11.4))/600-9.80665*sin(gradient_profile(x(:,2)))];
elseif p==4 % phase 4
    xdot = [v(:,1), zeros(length(t),1)]; % train 2 stopping at node 3
    vdot = [(force(:,1)-force(:,2)-(0.01644624*v(:,1).^2+0.3636*v(:,1)+11.4))/600-9.80665*sin(gradient_profile(x(:,1))), zeros(length(t),1)];
else % phase 1 or 3
    xdot = v; % both trains are moving
    vdot = [(force(:,1)-force(:,2)-(0.01644624*v(:,1).^2+0.3636*v(:,1)+11.4))/600-9.80665*sin(gradient_profile(x(:,1))), (force(:,3)-force(:,4)-(0.01644624*v(:,2).^2+0.3636*v(:,2)+11.4))/600-9.80665*sin(gradient_profile(x(:,2)))];
end

switch p
    case 1 % phase 1
        path=[force(:,1)-min(F_max_malfun, F_max_malfun-0.9*(3.6*v(:,1)-90)), force(:,2)-min(B_max, B_max-0.8*(3.6*v(:,1)-60)), force(:,3)-min(F_max, F_max-0.9*(3.6*v(:,2)-90)), force(:,4)-min(B_max, B_max-0.8*(3.6*v(:,2)-60)), x(:,1)-x(:,2)];
    case 2 % phase 2
        path=[force(:,3)-min(F_max, F_max-0.9*(3.6*v(:,2)-90)), force(:,4)-min(B_max, B_max-0.8*(3.6*v(:,2)-60))];
    case 3 % phase 3
        path=[force(:,1)-min(F_max_malfun, F_max_malfun-0.9*(3.6*v(:,1)-90)), force(:,2)-min(B_max, B_max-0.8*(3.6*v(:,1)-60)), force(:,3)-min(F_max, F_max-0.9*(3.6*v(:,2)-90)), force(:,4)-min(B_max, B_max-0.8*(3.6*v(:,2)-60)), x(:,2)-x(:,1)];
    case 4 % phase 4
        path=[force(:,1)-min(F_max_malfun, F_max_malfun-0.9*(3.6*v(:,1)-90)), force(:,2)-min(B_max, B_max-0.8*(3.6*v(:,1)-60))];
end;

dae = [xdot vdot path];

%-------------------------------%
% End File:  TrainSchedulingDae.m %
%-------------------------------%