function dae = TrainSchedulingDae(sol)

t = sol.time;
y = sol.state;
force = sol.control; % tractive and braking forces are the control variables

x = y(:,1); % location
v = y(:,2); % speed
xdot = v;
vdot = [(force(:,1)-force(:,2)-(0.01644624*v.^2+0.3636*v+11.4))/600-9.80665*sin(gradient_profile(x))];
path = [force(:,1)-min(140, 140-0.9*(3.6*v-90)), force(:,2)-min(200, 200-0.8*(3.6*v-60))];
dae = [xdot vdot path];

%-------------------------------%
% End File:  TrainSchedulingDae.m %
%-------------------------------%