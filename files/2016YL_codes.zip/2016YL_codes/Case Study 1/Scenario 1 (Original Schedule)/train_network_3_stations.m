%%% parameters of the line and train %%%

global station_location; 
global B_max; 
global F_max;
global v1_max;
global gd_table;
global current_arrival;
global current_departure;

current_departure = [0, 5*60]; % scheduled departure time; in second
current_arrival=[35*60, 40*60]; % scheduled arrival time; in second
station_location=[0 40000 80000]; % in meter
F_max=140; % upper bound of tractive force; in kN
B_max=200; % upper bound of braking force; in kN
v1_max=50; % speed limit; in m/s

% gradient
gd_table=[	 0.0	   0	2284
			-4.2	2284	3871
			 2.0	3871	6094
			16.7	6094	8181
			 0.0	8181	10323
			 1.7	10323	13750
			 0.0	13750	15711
			13.3	15711	19314
			 0.0	19314	21222
			-5.6	21222	23609
			-8.3	23609	27504
			-3.3	27504   30127	
			-8.3	30127	32778
			-2.5	32778	36003
			 0.0	36003	38091
			 0.5	38091	40000];
gd_table(:,1)=gd_table(:,1)/1000;
gd_table=[gd_table; [gd_table(:,1), gd_table(:,2:3)+40000]];
