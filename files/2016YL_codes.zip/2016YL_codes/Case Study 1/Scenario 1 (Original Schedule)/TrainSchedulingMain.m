tic

global station_location;
global B_max;
global F_max;
global v1_max;
global current_departure;
global current_arrival;

train_network_3_stations

limits.time.min = [current_departure(1), current_arrival(1)];
limits.time.max = [current_departure(1), current_arrival(1)];
limits.state.min   = [  station_location(1), station_location(1), station_location(3);
                        0,	0,	0];
limits.state.max  = [   station_location(1), station_location(3), station_location(3);
                        0,	v1_max,	0];
limits.control.min = [0; 0];
limits.control.max = [F_max; B_max];
limits.parameter.min    = [];
limits.parameter.max    = [];
limits.path.min    = [-F_max; -B_max];
limits.path.max    = [0; 0];
limits.duration.min = current_arrival(1)-current_departure(1);
limits.duration.max = current_arrival(1)-current_departure(1);
guess.time = [current_departure(1); current_arrival(1)];
guess.state = [	station_location(1), 0;
                station_location(3), 0];
guess.control = [F_max, 0;
                 0, B_max];
guess.parameter = [];

colpoints_num=440; 
meshpoint_num=1;
limits.meshPoints = [-1:2/meshpoint_num:1];
limits.nodesPerInterval = colpoints_num*ones(1,meshpoint_num);

setup.name = 'TrainScheduling';
setup.funcs.cost = 'TrainSchedulingCost';
setup.funcs.dae = 'TrainSchedulingDae';
setup.limits = limits;
setup.guess = guess; 

setup.derivatives ='complex';
setup.autoscale = 'off';
setup.tolerances = [4.2e-3, 2.5e-4];
setup.mesh.iteration = 0;
%setup.mesh.tolerance = 1e-2;
%setup.mesh.maxIterations = 20;
%setup.mesh.nodesPerInterval.min = 4;
%setup.mesh.nodesPerInterval.max = 12;
setup.printoff = 0;

[output,gpopsHistory] = gpops(setup);

toc

plotfigures;

%--------------------------------%
% End File:  TrainSchedulingMain.m %
%--------------------------------%
