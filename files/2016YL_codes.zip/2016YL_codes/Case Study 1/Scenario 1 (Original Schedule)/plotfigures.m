%%% visualize the result %%%

solution = output.solution;

figure;
subplot(2,1,1);
hold on;
for iphase=1:length(solution)
    p1 = plot(solution(iphase).state(:,1)/1000, 3.6*solution(iphase).state(:,2),'-b');
    hold on;
end;
p2 = plot([station_location(1)/1000, station_location(3)/1000], [180,180], 'k--'); % plot speed limit
set(gca,'fontsize',12);
xlabel('Location(km)', 'fontsize', 12);
ylabel('Speed (km/hr)', 'fontsize', 12);
legend([p2,p1],'Speed limit','Speed profile');

subplot(2,1,2);
for iphase=1:length(solution)
    p1 = plot(solution(iphase).state(:,1)/1000, solution(iphase).control(:,1),'r-', 'linewidth',1);
    p1.Color(4) = 0.5;
    hold on;
    p2 = plot(solution(iphase).state(:,1)/1000, -solution(iphase).control(:,2),'b-.', 'linewidth',1);
    hold on;
	p3 = plot(solution(iphase).state(:,1)/1000, min(140, 140-0.9*(3.6*solution(iphase).state(:,2)-90)),'--k', 'linewidth', 0.5);
    hold on;
    p4 = plot(solution(iphase).state(:,1)/1000, -min(200, 200-0.8*(3.6*solution(iphase).state(:,2)-60)),':k', 'linewidth',0.5);
    hold on;
end;
set(gca,'fontsize',12);
xlabel('Location (km)', 'fontsize', 12);
ylabel('Force (kN)', 'fontsize', 12);
legend([p1,p2,p3,p4],'$F$','$-B$','$\bar{F}(v)$', '$-\bar{B}(v)$', 'Interpreter','latex');