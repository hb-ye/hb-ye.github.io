The codes are for the case study in Section 5.2 of the paper "Yang, H., Ye, H., Li, X. and Zhao, B., 2015. Speed limits, speed selection and network equilibrium. Transportation Research Part C 51, 260-273."

main_4_link.m			the main programme
network_4_link.m		description of the network
frank_wolfe.m			the Frank-Wolfe method for single-class traffic assignment
travel_time_function.m	the link travel time function
utility_function.m		the total disutility function of a link