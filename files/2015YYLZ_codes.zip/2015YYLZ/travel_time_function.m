function t=travel_time_function(v,t0,cap)

t=t0.*(1+0.15.*(v./cap).^4);
