function link_flow_m=frank_wolfe(link_flow_m, link_flow_else,v_opt,s_opt,s_avg,od_class,n)

global speed_limit;
global link_length;
global free_flow_time;
global link_capacity;
global link_to_node;
global node_to_link;
global node_num;
global link_num;
global od_demand;
global kappa_c;
global options;

error_c=1;
while error_c>kappa_c
    u=utility_function(link_flow_m+link_flow_else,v_opt,s_opt,s_avg,speed_limit,link_length,free_flow_time,link_capacity,n);

    %------ find shortest path with new flow loading & link travel costs
    DG=sparse(link_to_node(:,1),link_to_node(:,2),u,node_num,node_num);
    link_flow_temp=zeros(link_num,1);
    for i=1:length(od_class)
        [dist,path,pred]=graphshortestpath(DG,od_demand(od_class(i),2),od_demand(od_class(i),3),'Directed',true);
        for j=1:length(path)-1
            k=node_to_link(path(j),path(j+1));
            link_flow_temp(k)=link_flow_temp(k)+od_demand(od_class(i),4);
        end;
    end;
    
    %------ find the optimal descent direction
    
    d=link_flow_temp-link_flow_m;
    
    [x1,y1]= fminbnd(@(a) sum(d.*utility_function(link_flow_m+link_flow_else+a*d,v_opt,s_opt,s_avg,speed_limit,link_length,free_flow_time,link_capacity,n)), 0,1,options);
    [x2,y2]= fminbnd(@(a) -sum(d.*utility_function(link_flow_m+link_flow_else+a*d,v_opt,s_opt,s_avg,speed_limit,link_length,free_flow_time,link_capacity,n)), 0,1,options);
    y2=-y2;

    if y1<=0 && y2>=0
        a = fzero(@(a) sum(d.*utility_function(link_flow_else+link_flow_m+a*d,v_opt,s_opt,s_avg,speed_limit,link_length,free_flow_time,link_capacity,n)),0 ,options);
    else if y1>0
            a=x1;
        else
            a=x2;
        end;
    end;
    
    %------ update the link flows
    link_flow_new = link_flow_m + a * d;
    
    error_c=sum((link_flow_new - link_flow_m).^2)/sum(link_flow_m.^2);
    link_flow_m=link_flow_new;
end;
