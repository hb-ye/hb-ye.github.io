global node_num;
global link_num;
global od_num;
global user_class_num;
global link_capacity;
global free_flow_speed;
global free_flow_time;
global link_length;
global speed_limit;
global od_demand;
global link_to_node;
global node_to_link;
global alpha;
global beta;
global gamma;
global xi;
global eta;

%%**********  4-link  ************* 
node_num=4;
link_num=4;
user_class_num=2;
od_num=4;
link_capacity=[  200 350 400 300]';
link_length=[ 55 20 20 32]';
free_flow_time=[ 40 15 12 20]'./60;
free_flow_speed=link_length./free_flow_time;
speed_limit=[ 60 60 70 60]';
alpha=[ 2 4 ]*1e-5;
beta=[ 10 30 ];
gamma=[ 1 2 ]*1e-4;
xi=[ 2.5 2.5 2
     2.5 2.5 2 ];
eta=[ 2 2];
od_demand = [	1   1   2   200
                1   1   4   200
                2   1   2   200
                2   1   4   200	];
link_to_node = [	1   2
                    1   3
                    3   2
                    3   4   ];
node_to_link = sparse(link_to_node(:,1),link_to_node(:,2),[1:link_num]);
%%**********   4-link  *************
