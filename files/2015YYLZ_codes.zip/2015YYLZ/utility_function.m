function u=utility_function(v_total,v_opt,s_opt,s_avg,speed_limit,link_length,free_flow_time,link_capacity,user_class)
global alpha;
global beta;
global gamma;
global xi;
global eta;

% ----- Crash Risk + Travel Time + Ticket Risk
z=zeros(size(s_opt,1),size(s_opt,2));
x=z;
x(find(v_total>v_opt))=1;
s_m=(1-x).*s_opt+x.*link_length./travel_time_function(v_total,free_flow_time,link_capacity);

%--- crash risk
x=z;
x(find(s_avg>s_m))=1; %s_avg>s_m
y=1-x; %s_m>s_avg
crash_cost=(x.*(s_avg-s_m)).^xi(user_class,1)+(y.*(s_m-s_avg)).^xi(user_class,2)+s_m.^xi(user_class,3);

%--- travel time
travel_time=1./s_m;

%--- ticket risk
x=z;
x(find(s_m>speed_limit))=1; %s_m>speed_limit
ticket_cost=(x.*(s_m-speed_limit)).^eta(user_class);

%--- total disutility
u=link_length.*(alpha(user_class).*crash_cost+beta(user_class).*travel_time+gamma(user_class).*ticket_cost);
