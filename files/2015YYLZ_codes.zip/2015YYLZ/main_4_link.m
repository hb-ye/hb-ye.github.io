clear;
clc;

%%--- loading network
network_4_link

global epsilon;
global kappa;
global kappa_c;
global kappa_f;
global options;
epsilon=1e-21;
kappa=1e-21;
kappa_c=1e-21;
kappa_f=1e-21;
options=optimset('TolFun',epsilon,'TolX',epsilon);

%------ initial loading
link_flow_heter=zeros(link_num,user_class_num);
DG=sparse(link_to_node(:,1),link_to_node(:,2),free_flow_time,node_num,node_num);
for i=1:od_num
    [dist,path,pred]=graphshortestpath(DG,od_demand(i,2),od_demand(i,3),'Directed',true);
    m=od_demand(i,1);
    for j=1:length(path)-1
        k=node_to_link(path(j),path(j+1));
        link_flow_heter(k,m)=link_flow_heter(k,m)+od_demand(i,4);
    end;
end;

link_flow_total=sum(link_flow_heter,2);
s_avg=free_flow_speed;
s_heter=free_flow_speed(:,ones(1,user_class_num));

error=1;

while error>kappa
    %-------- multi-class traffic assignment, given s_avg
    error_f=1;
    while error_f>kappa_f
        link_flow_heter_old=link_flow_heter;
        link_flow_total_old=link_flow_total;
        for n=1:user_class_num
            link_flow_m=link_flow_heter(:,n);
            link_flow_else=link_flow_total-link_flow_m;
            od_class=find(od_demand(:,1)==n);
            for i=1:link_num
                s_opt(i,1)=fminbnd(@(s_opt) utility_function(1,2,s_opt,s_avg(i),speed_limit(i),link_length(i),free_flow_time(i),link_capacity(i),n),0,free_flow_speed(i));
                v_opt(i,1)=abs(fzero(@(v) link_length(i)/travel_time_function(v,free_flow_time(i),link_capacity(i))-s_opt(i,1),0 ));
            end;
            
            %------ Frank Wolfe ( Convex Combination )
            link_flow_m=frank_wolfe(link_flow_m, link_flow_else,v_opt,s_opt,s_avg,od_class,n);
            
            link_flow_heter(:,n)=link_flow_m;
            s_sup=link_length./travel_time_function(link_flow_else+link_flow_m,free_flow_time,link_capacity);
            s_heter(:,n)=min(s_opt,s_sup);
            link_flow_total=sum(link_flow_heter,2);
        end;
        error_f=sum(sum((link_flow_heter-link_flow_heter_old).^2))/sum(sum(link_flow_heter_old.^2));
    end;

    for i=1:link_num
        k=sum(link_flow_heter(i,:));
        if k<1e-6
            s_avg_new(i,1)=sum(s_heter(i,:))/user_class_num;
        else
            s_avg_new(i,1)=sum(s_heter(i,:).*link_flow_heter(i,:))/k;
        end;
    end;
    
    error=sum((s_avg-s_avg_new).^2)/sum(s_avg.^2)
    s_avg=s_avg_new;
end;

% Final Result
v=sum(link_flow_heter,2);
s_sup=link_length./travel_time_function(v,free_flow_time,link_capacity);
for n=1:user_class_num
    for i=1:link_num
        s_opt(i,n)=fminbnd(@(s_opt) utility_function(1,2,s_opt,s_avg(i),speed_limit(i),link_length(i),free_flow_time(i),link_capacity(i),n),0,free_flow_speed(i));
        v_opt(i,n)=abs(fzero(@(v) link_length(i)/travel_time_function(v,free_flow_time(i),link_capacity(i))-s_opt(i,n),0 ));
    end;
end
for n=1:user_class_num
    u(:,n)=utility_function(v,v_opt(:,n),s_opt(:,n),s_avg,speed_limit,link_length,free_flow_time,link_capacity,n);
end;

z=[link_flow_heter, s_heter, s_sup, s_opt, s_avg, u];
