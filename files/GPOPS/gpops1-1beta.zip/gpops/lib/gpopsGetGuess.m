function setup = gpopsGetGuess(setup);
%------------------------------------------------------------------%
% Get the guess used by the NLP solver in a non-sequential         %
% multiple-phase optimal control problem.                          %
%------------------------------------------------------------------%
% GPOPS Copyright (c) Anil V. Rao, Geoffrey T. Huntington, David   %
% Benson, Michael Patterson, Christopher Darby, & Camila Francolin %
%------------------------------------------------------------------%

minima = setup.limits{1};
solinit = setup.solinit;
numphases = size(minima,1);
if size(solinit,1)>numphases,
    solinit = solinit(1:numphases,:);
end;
sizes = setup.sizes;
nodes = setup.nodes;
init = cell(numphases,1);
ps = cell(numphases,4);
for iphase=1:numphases;
    % ------------------------------------------
    % Get the guess in each phase of the problem
    % ------------------------------------------
    nstates = sizes(iphase,1);
    ncontrols = sizes(iphase,2);
    % nparameters = sizes(iphase,3);
    tinit    = solinit{iphase,1};
    xinit    = solinit{iphase,2};
    if ~isempty(solinit{iphase,3}),
        uinit    = solinit{iphase,3};
    else
        uinit = [];
    end;
    if ~isempty(solinit{iphase,4}),
        pinit    = solinit{iphase,4};
    else
        pinit = [];
    end;
    t0init   = tinit(1);
    tfinit   = tinit(end);
    Gauss  = gpopsGPM(nodes(iphase));
    ps{iphase,1}  = Gauss.Differentiation_Matrix;
    ps{iphase,2}  = Gauss.Points;
    ps{iphase,3} =  Gauss.Weights.';
    ps{iphase,4} = Gauss.Differentiation_Matrix_Diag;
    tau_plus_ends = [-1; Gauss.Points; 1];
    tinterp  = (tfinit-t0init)*(tau_plus_ends+1)/2+t0init;
    if nstates>0,
        xinterp = interp1(tinit,xinit,tinterp,'spline');
    else
	xinterp = [];
    end;
    if ncontrols>0,
        uinterp = interp1(tinit,uinit,tinterp(2:end-1),'spline');
    else
	uinterp = [];
    end;
    init{iphase,1} = [xinterp(:); uinterp(:); t0init; tfinit; pinit];
end;
init_vector = vertcat(init{:,1});
setup.init_vector = init_vector;
setup.ps = ps;
