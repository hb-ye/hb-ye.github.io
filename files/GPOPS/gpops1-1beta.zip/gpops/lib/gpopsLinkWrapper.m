function link = gpopsLinkWrapper(t,xplink,extras);
%------------------------------------------------------------------%
% Wrapper function to evaluate linkage constraints                 %
%------------------------------------------------------------------%
% GPOPS Copyright (c) Anil V. Rao, Geoffrey T. Huntington, David   %
% Benson, Michael Patterson, Christopher Darby, & Camila Francolin %
%------------------------------------------------------------------%

setup = extras{1};
left_phase = extras{2}(1);
right_phase = extras{2}(2);
nstates_left = extras{3}(1);
nstates_right = extras{3}(2);
nparameters_left = extras{4}(1);
nparameters_right = extras{4}(2);
ll = length(xplink);
xpleft = xplink(1:nstates_left+nparameters_left);
xpright = xplink(nstates_left+nparameters_left+1:end);
sol{1} = xpleft(1:nstates_left);
sol{2} = xpleft(nstates_left+1:nstates_left+nparameters_left);
sol{3} = xpright(1:nstates_right);
sol{4} = xpright(nstates_right+1:nstates_right+nparameters_right);

link = feval(setup.funcs{4},sol,left_phase,right_phase);
