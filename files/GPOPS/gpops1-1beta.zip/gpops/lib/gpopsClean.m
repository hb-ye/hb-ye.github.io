function gpopsClean;
%------------------------------------------------------------------%
% This function cleans all output files from a run of GPOPS.       %
% The files cleaned by this function are as follows:               %
%   (1)  The main snopt output file:  snoptmain.out                %
%   (2)  The endpoint control snopt output files:                  %
%        snoptmain0.out, snoptmainF.out                            %
%   (3)  The text file with the problem statement                  %
%------------------------------------------------------------------%
% GPOPS Copyright (c) Anil V. Rao, Geoffrey T. Huntington, David   %
% Benson, Michael Patterson, Christopher Darby, & Camila Francolin %
%------------------------------------------------------------------%

warning off;
delete('*.txt');
if exist('snoptmain.out','file')==2,
    delete('snoptmain.out');
end;
if exist('snoptmain0.out','file')==2,;
    delete('snoptmain0.out');
end;
if exist('snoptmainF.out','file')==2;
    delete('snoptmainF.out');
end;

