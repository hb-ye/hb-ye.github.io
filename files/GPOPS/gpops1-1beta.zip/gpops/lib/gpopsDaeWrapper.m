function dae = gpopsDaeWrapper(t,xup,extras);
%------------------------------------------------------------------%
% Wrapper function for differential-algebraic equations            %
%------------------------------------------------------------------%
% GPOPS Copyright (c) Anil V. Rao, Geoffrey T. Huntington, David   %
% Benson, Michael Patterson, Christopher Darby, & Camila Francolin %
%------------------------------------------------------------------%

setup = extras{1};
iphase = extras{2};
nstates = extras{3};
ncontrols = extras{4};
nparameters = extras{5};
daefunc = setup.funcs{2};
sol{1} = t;
sol{2} = xup(1:nstates).';
sol{3} = xup(nstates+1:nstates+ncontrols).';
sol{4} = xup(nstates+ncontrols+1:nstates+ncontrols+nparameters);
dae = feval(daefunc,sol,iphase).';

