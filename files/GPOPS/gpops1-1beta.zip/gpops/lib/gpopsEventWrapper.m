function event = gpopsEventWrapper(t,xup,extras);
%------------------------------------------------------------------%
% Wrapper function to evaluate event constraints                   %
%------------------------------------------------------------------%
% GPOPS Copyright (c) Anil V. Rao, Geoffrey T. Huntington, David   %
% Benson, Michael Patterson, Christopher Darby, & Camila Francolin %
%------------------------------------------------------------------%

setup = extras{1};
iphase = extras{2};
nstates = extras{3};
ncontrols = extras{4};
nparameters = extras{5};
eventfunc = setup.funcs{3};
init = xup(1:nstates+1);
term = xup(nstates+2:2*(nstates+1));
p = xup(2*(nstates+1)+1:end);
sol{1} = init(1);
sol{2} = init(2:nstates+1);
sol{3} = term(1);
sol{4} = term(2:nstates+1);
sol{5} = p;

event = feval(eventfunc,sol,iphase);
