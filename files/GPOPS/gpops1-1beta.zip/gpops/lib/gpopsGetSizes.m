function setup = gpopsGetSizes(setup);
%------------------------------------------------------------------%
% Get all sizes in a multiple-phase optimal control problem        %
%------------------------------------------------------------------%
% GPOPS Copyright (c) Anil V. Rao, Geoffrey T. Huntington, David   %
% Benson, Michael Patterson, Christopher Darby, & Camila Francolin %
%------------------------------------------------------------------%

%-----------------------------------------------------------%
% Grab the sizes of the cell arrays limits{1} and limits{2} %
%-----------------------------------------------------------%
[rmin,cmin] = size(setup.limits{1});
[rmax,cmax] = size(setup.limits{2});
if ~isequal(rmin,rmax) || ~isequal(cmin,cmax),
    error('Minima and Maxima Cell Arrays Must Be Same Size');
end;
numphases = size(setup.limits{1},1);

%-------------------------------------------------------------------%
% Set auxiliary variables for the lower and upper bound cell arrays %
%-------------------------------------------------------------------%

% Set up two cell arrays MINIMA and MAXIMA for ease of coding
minima = cell(numphases,7);
maxima = cell(numphases,7);
for iphase=1:numphases
    for j=1:size(setup.limits{1},2)
	minima{iphase,j} = setup.limits{1}{iphase,j};
	maxima{iphase,j} = setup.limits{2}{iphase,j};
    end;
end;
setup.limits{1} = minima;
setup.limits{2} = maxima;
%--------------------------------------------------------------------%
% Get sizes of the following variables in each phase of the problem: %
%--------------------------------------------------------------------%
%    states                                                          %
%    controls                                                        %
%    parameters                                                      %
%    path constraints                                                %
%    event constraints                                               %
%--------------------------------------------------------------------%
sizes = zeros(numphases,5);
for iphase=1:numphases;
    %-----------------------------------------------------%
    % Determine the number of states in the current phase %
    %-----------------------------------------------------%
    if (~isempty(minima{iphase,2}) && ~isempty(maxima{iphase,2})),
        if isequal(size(minima{iphase,2}),size(maxima{iphase,2})),
            nstates     = size(minima{iphase,2},1);
        else
            error('State Upper & Lower Bound Matrices Must Be Same Size');
        end;
    else
        nstates = 0;
    end;
    %-------------------------------------------------------%
    % Determine the number of controls in the current phase %
    %-------------------------------------------------------%
    if (~isempty(minima{iphase,3}) && ~isempty(maxima{iphase,3})),
        if isequal(size(minima{iphase,3}),size(maxima{iphase,3})),
            ncontrols   = size(minima{iphase,3},1);
        else
            error('Control Upper & Lower Bound Matrices Must Be Same Size');
        end;
    else
        ncontrols = 0;
    end;
    %----------------------------------------------------------------%
    % Determine the number of static parameters in the current phase %
    %----------------------------------------------------------------%
    if (~isempty(minima{iphase,4}) && ~isempty(maxima{iphase,4})),
        if isequal(size(minima{iphase,4}),size(maxima{iphase,4})),
            nparameters   = size(minima{iphase,4},1);
        else
            error('Parameter Upper and Lower Bound Vector Must Be Same Size');
        end;
    else
        nparameters = 0;
    end;
    %-------------------------------------------------%
    % Number of path constraints in the current phase %
    %-------------------------------------------------%
    if (~isempty(minima{iphase,5}) && ~isempty(maxima{iphase,5})),
        if isequal(size(minima{iphase,5}),size(maxima{iphase,5})),
            npaths        = size(minima{iphase,5},1);
        else
            error('Path Upper and Lower Bound Vector Must Be Same Size');
        end;
    else
        npaths = 0;
    end;
    %--------------------------------------------------%
    % Number of event constraints in the current phase %
    % -------------------------------------------------%
    if (~isempty(minima{iphase,6}) && ~isempty(maxima{iphase,6})),
        if isequal(size(minima{iphase,6}),size(maxima{iphase,6})),
            nevents       = size(minima{iphase,6},1);
        else
            error('Event Upper and Lower Bound Vector Must Be Same Size');
        end;
    else
        nevents = 0;
    end;
    %-----------------------------------------------------------------%
    % Set the row vector of sizes in the array SIZES.                 %
    % The IPHASE row of SIZES contains information about phase IPHASE %
    % The order of information in SIZES is as follows:                %
    %   SIZES(IPHASE,1) = number of states in phase IPHASE            %
    %   SIZES(IPHASE,2) = number of controls in phase IPHASE          %
    %   SIZES(IPHASE,3) = number of static parameters in phase IPHASE %
    %   SIZES(IPHASE,4) = number of path constraints in phase  IPHASE %
    %   SIZES(IPHASE,5) = number of event constraints in phase IPHASE %
    % ----------------------------------------------------------------%
    sizes(iphase,:)  = [nstates ncontrols nparameters npaths nevents];
end;
%-------------------------------------------------------%
% Put the array SIZES as a field in th structure SETUP. %
%-------------------------------------------------------%
setup.sizes = sizes;
