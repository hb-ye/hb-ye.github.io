function F=gpopsEndPointControl(u);
%------------------------------------------------------------------%
% Computes the Hamiltonian and the path constraints in order to    %
% compute the endpoint control for multiple-phase optimal control  %
% problem.  The endpoint control algorithm is given in the         %
% following reference:                                             %
%   Huntington, G. T., Benson, D. A., How, J. P., Kanizay, N.,     %
%   Darby, C. L., and Rao, A. V., "Computation of Endpoint Controls%
%   Using a Gauss Pseudospectral Method," 2007 Astrodynamics       %
%   Specialist Conference, Mackinac Island, Michigan,              %
%   August 19-23, 2007.                                            %
%------------------------------------------------------------------%
% GPOPS Copyright (c) Anil V. Rao, Geoffrey T. Huntington, David   %
% Benson, Michael Patterson, Christopher Darby, & Camila Francolin %
%------------------------------------------------------------------%
global extras funcs

t      = extras{1};
x      = extras{2};
p      = extras{3};
lambda = extras{4};
iphase = extras{5};

nstates = length(x);
solcost{1,1} = t;
solcost{1,2} = x.';
solcost{1,3} = t;
solcost{1,4} = x.';
solcost{2,1} = t;
solcost{2,2} = x;
solcost{2,3} = u.';
solcost{2,4} = p;
solode{1} = t;
solode{2} = x;
solode{3} = u.';
solode{4} = p;
[Mayer,Lagrangian]=feval(funcs{1},solcost,iphase);
dae = feval(funcs{2},solode,iphase);
xdot = dae(1:nstates).';
path = dae(nstates+1:end).';
H = Lagrangian+lambda*xdot;
F = [H; path];
