% -------------------- %
% Setup File for GPOPS %
% -------------------- %
% Notes: 
%   (1) This file assumes that you have write permissions
%       to change the MATLAB path.  If you do cannot change the
%       MATLAB path, contact your system administrator.
%   (2) MAD and SNOPT are not included in the GPOPS distribution.
%       These software programs must be obtained and installed separately.
currdir = pwd;
libdir = strcat(currdir,'/lib/');
addpath(libdir,path,'-begin');
savepath;
