%-----------------------------------
% BEGIN: script hyperSensitiveMain.m
%-----------------------------------
% This m-file is the main file for the following optimal control
% problem: 
%   minimize
%     J = 0.5*(x^2+u^2)
%   subject to
%     dx/dt = -x^3 + u
%     x(0) = 1.5
%     x(tf) = 1
%------------------------------------------------------------------
% This example is taken from the following reference:
% Rao, A. V. and Mease, K. D., "Eigenvector Approximate Dichotomic
% Basis Method for Solving Hypersensitive Optimal Control
% Problems," Optimal Control Applications and Methods, Vol. 21,
% No. 1, 2000, pp. 1-19.
%------------------------------------------------------------------
gpopsInitialize;

x0 = 1.5;
xf = 1;
xmin = -50;
xmax =  50;
umin = -50;
umax =  50;

iphase = 1;
limits{imin}{iphase,itime} = [0 50];
limits{imax}{iphase,itime} = [0 50];
limits{imin}{iphase,istate} = [x0 xmin xf];
limits{imax}{iphase,istate} = [x0 xmax xf];
limits{imin}{iphase,icontrol} = umin;
limits{imax}{iphase,icontrol} = umax;
limits{imin}{iphase,iparameter} = [];
limits{imax}{iphase,iparameter} = [];
limits{imin}{iphase,ipath} = [];
limits{imax}{iphase,ipath} = [];
limits{imin}{iphase,ievent} = [];
limits{imax}{iphase,ievent} = [];
solinit{iphase,1} = [0; 20];
solinit{iphase,2} = [x0; x0];
solinit{iphase,3} = [0; 0];

solinit{iphase,4} = []; % No parameters in Phase 1

clear x0 xf xmin xmax umin umax

setup.name  = 'HyperSensitive-Problem';
setup.funcs = {'hyperSensitiveCost','hyperSensitiveDae'};
setup.nodes =27;
setup.limits = limits;
setup.solinit = solinit;
setup.connections = [];
setup.derivatives = 'complex';
setup.direction = 'increasing';
setup.autoscale = 'off';

output = gpops(setup);
solution = output.solution;
