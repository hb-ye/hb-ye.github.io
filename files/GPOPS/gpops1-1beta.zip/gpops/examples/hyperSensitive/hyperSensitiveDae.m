function dae = hyperSensitiveDae(sol,iphase);

t = sol{1};
x = sol{2};
u = sol{3};
p = sol{4};

dae = -x.^3+u;
