function events = brysonDenhamEvent(sol,iphase);

t0 = sol{1};
x0 = sol{2};
tf = sol{3};
xf = sol{4};

events(1:5,:) = [x0; xf(1:2)];
