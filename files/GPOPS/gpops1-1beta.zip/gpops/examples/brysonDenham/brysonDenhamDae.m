function dae = brysonDenhamDae(sol,iphase);

t = sol{1};
x = sol{2};
u = sol{3};
x1dot = x(:,2);
x2dot = u;
x3dot = u.^2/2;
path = x(:,1);

dae = [x1dot x2dot x3dot path];

