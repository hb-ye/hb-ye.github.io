% -----------------------------
% Bryson-Denham Example Problem
% -----------------------------
% --------------------------------------------------
% This example is taken from the following reference:
% --------------------------------------------------
% Bryson, A. E., Denham, W. F., and Dreyfus, S. E., "Optimal
% Programming Problems with Inequality Constraints.  I: Necessary
% Conditions for Extremal Solutions, AIAA Journal, Vol. 1, No. 11,
% November, 1963, pp. 2544-2550.
gpopsInitialize;

x10 = 0;
x20 = 1;
x30 = 0;
x1f = 0;
x2f = -1;
x1min = -10;
x1max = 10;
x2min = x1min;
x2max = x1max;
x3min = x1min;
x3max = x1max;

param_min = [];
param_max = [];
path_min = 0;
path_max = 1/9;
event_min = [x10; x20; x30; x1f; x2f];
event_max = [x10; x20; x30; x1f; x2f];
duration_min = [];
duration_max = [];

iphase = 1;
limits{imin}{iphase,itime} = [0 0];
limits{imax}{iphase,itime} = [0 50];
limits{imin}{iphase,istate}(1,:) = [x1min x1min x1min];
limits{imax}{iphase,istate}(1,:) = [x1max x1max x1max];
limits{imin}{iphase,istate}(2,:) = [x2min x2min x2min];
limits{imax}{iphase,istate}(2,:) = [x2max x2max x2max];
limits{imin}{iphase,istate}(3,:) = [x3min x3min x3min];
limits{imax}{iphase,istate}(3,:) = [x3max x3max x3max];
limits{imin}{iphase,icontrol} = -5000;
limits{imax}{iphase,icontrol} =  5000;
limits{imin}{iphase,iparameter} = param_min;
limits{imax}{iphase,iparameter} = param_max;
limits{imin}{iphase,ipath} = path_min;
limits{imax}{iphase,ipath} = path_max;
limits{imin}{iphase,ievent} = event_min;
limits{imax}{iphase,ievent} = event_max;
limits{imin}{iphase,iduration} = [];
limits{imax}{iphase,iduration} = [];
solinit{iphase,itime} = [0; 0.5];
solinit{iphase,istate}(:,1) = [x10; x1f];
solinit{iphase,istate}(:,2) = [x20; x2f];
solinit{iphase,istate}(:,3) = [x30; x30];
solinit{iphase,icontrol} = [0; 0];
solinit{iphase,iparameter} = []; % No parameters in Phase 1

clear x10 x20 x30 x1f x2f x1min x1max x2min x2max x3min x3max param_min param_max path_min path_max event_min event_max duration_min duration_max iphase;

setup.name  = 'Bryson-Denham-Problem';
setup.funcs{1} = 'brysonDenhamCost';
setup.funcs{2} = 'brysonDenhamDae';
setup.funcs{3} = 'brysonDenhamEvent';
setup.funcs{4} = 'brysonDenhamConnect';
setup.nodes = 55;
setup.limits = limits;
setup.solinit = solinit;
setup.connections = [];
setup.derivatives = 'complex';
setup.direction = 'increasing';
setup.autoscale = 'off';

output = gpops(setup);
solution = output.solution;
