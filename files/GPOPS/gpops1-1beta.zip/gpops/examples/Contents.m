% Contents.m
% 
% runallexamples:   File to Run All Examples in GPOPS Distribution
% brysonDenham:     The Bryson-Denham Problem
% brysonMaxRange:   The Bryson Maximum-Range Problem
% chemicalProcess:  The Kokotovic Chemical Process Problem
% hyperSensitive:   The Rao-Mease Hyper-Sensitive Problem
% launch:           The Benson-Huntington-Rao Launch Vehicle Ascent Problem
% minimumClimb:     The Bryson Minimum Time-to-Climb Problem
% moonLander:       The One-Dimensonal Moon Landing Problem
% rvlEntry:         The Betts RLV Entry Problem
%
% All of the examples listed above are in the OPEN LITERATURE.  
% -------------------------------------------------------------------%
% !!!!! WARNING WARNING WARNING WARNING WARNING WARNING WARNING!!!!! %
% -------------------------------------------------------------------%
% ONLY EXAMPLES FOUND IN THE OPEN LITERATURE CAN BE ADDED TO THE
% GPOP DISTRIBUTION.  ANY PROPRIETARY OR OTHERWISE RESTRICTED
% EXAMPLES ARE PROHIBITED FROM INCLUSION INTO THE SOURCE CODE
% DISTRIBUTION OF DYNAMO.
