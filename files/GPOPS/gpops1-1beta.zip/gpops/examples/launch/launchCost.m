function [Mayer,Lagrange] = launchCost(sol,iphase);

t0 = sol{1,1};
x0 = sol{1,2};
tf = sol{1,3};
xf = sol{1,4};
t = sol{2,1};
x = sol{2,2};
u = sol{2,3};
p = sol{2,4};

Lagrange = zeros(size(t));
if iphase==4,
    Mayer = -xf(7);
else
    Mayer = zeros(size(t0));
end;

