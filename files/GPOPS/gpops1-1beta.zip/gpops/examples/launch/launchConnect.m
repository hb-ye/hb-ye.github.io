function connect = launchConnect(sol,left_phase,right_phase);

xf_left = sol{1};
p_left = sol{2};
x0_right = sol{3};
p_right = sol{4};

connect = zeros(size(xf_left));
connect = x0_right-xf_left;
