function events = launchEvent(sol,iphase);

global CONSTANTS
t0 = sol{1};
x0 = sol{2};
tf = sol{3};
xf = sol{4};
p  = sol{5};

if iphase==4,
    oe = launchrv2oe(xf(1:3),xf(4:6),CONSTANTS.mu);
    events= zeros(size(x0(1:5)));
    events(1:5) = oe(1:5);
end;
