% -----------------------------
% Bryson-Denham Example Problem
% -----------------------------
% -----------------------------------------------------------------
% This example can be found in one of the following two references:
% -----------------------------------------------------------------
% Bryson, A. E. and Ho, Y-C, Applied Optimal Control, Hemisphere
% Publishing, New York, 1975.
% 
% Betts, J.T., Practical Methods for Optimal Control Using
% Nonlinear Programming, Second Edition, SIAM Press, Philadelphia,
% forthcoming. 

iplot = true;
imin = 1; imax = 2;
itime = 1; istate = 2; icontrol = 3; iparameter = 4;
ipath = 5; ievent = 6; iduration = 7;
x10 = 0;
x20 = 0;
x30 = 0;
x40 = 0;
x2f = 5;
x3f = 45;
x4f = 0;
x1min = -100;
x1max = 100;
x2min = x1min;
x2max = x1max;
x3min = x1min;
x3max = x1max;
x4min = x1min;
x4max = x1max;

param_min = [];
param_max = [];
duration_min = [];
duration_max = [];

iphase = 1;
limits{imin}{iphase,itime} = [0 0];
limits{imax}{iphase,itime} = [0 100];
limits{imin}{iphase,istate}(1,:) = [x10 x1min x1min];
limits{imax}{iphase,istate}(1,:) = [x10 x1max x1max];
limits{imin}{iphase,istate}(2,:) = [x20 x2min x2f];
limits{imax}{iphase,istate}(2,:) = [x20 x2max x2f];
limits{imin}{iphase,istate}(3,:) = [x30 x3min x3f];
limits{imax}{iphase,istate}(3,:) = [x30 x3max x3f];
limits{imin}{iphase,istate}(4,:) = [x40 x3min x4f];
limits{imax}{iphase,istate}(4,:) = [x40 x3max x4f];
limits{imin}{iphase,icontrol} = -100;
limits{imax}{iphase,icontrol} =  100;
limits{imin}{iphase,iparameter} = [];
limits{imax}{iphase,iparameter} = [];
limits{imin}{iphase,ipath} = [];
limits{imax}{iphase,ipath} = [];
limits{imin}{iphase,ievent} = [];
limits{imax}{iphase,ievent} = [];
limits{imin}{iphase,iduration} = [];
limits{imax}{iphase,iduration} = [];
solinit{iphase,itime} = [0; 0.5];
solinit{iphase,istate}(:,1) = [x10; x10];
solinit{iphase,istate}(:,2) = [x20; x2f];
solinit{iphase,istate}(:,3) = [x30; x3f];
solinit{iphase,istate}(:,4) = [x40; x4f];
solinit{iphase,icontrol} = [0; 0];
solinit{iphase,iparameter} = [];

setup.name  = 'Linear-Tangent-Steering-Problem';
setup.funcs{1} = 'linearTangentCost';
setup.funcs{2} = 'linearTangentDae';
setup.funcs{3} = 'linearTangentEvent';
setup.funcs{4} = 'linearTangentConnect';
setup.nodes = 40;
setup.limits = limits;
setup.solinit = solinit;
setup.connections = [];
setup.derivatives = 'complex';
setup.direction = 'increasing';
setup.autoscale = 'off';

output = gpops(setup);
solution = output.solution;
