function dae = linearTangentDae(sol,iphase);

a = 100;

t = sol{1};
x = sol{2};
u = sol{3};
x1dot = x(:,3);
x2dot = x(:,4);
x3dot = a.*cos(u);
x4dot = a.*sin(u);

dae = [x1dot x2dot x3dot x4dot];

