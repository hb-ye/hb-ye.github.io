function [Mayer,Lagrange]=brysonMaxrangeCost(sol,iphase);

t0 = sol{1,1};
x0 = sol{1,2};
tf = sol{1,3};
xf = sol{1,4};
t = sol{2,1};
x = sol{2,2};
u = sol{2,3};
p = sol{2,4};

Mayer    = -xf(1); % Maximize the horizontal range
Lagrange = zeros(size(t));
 

