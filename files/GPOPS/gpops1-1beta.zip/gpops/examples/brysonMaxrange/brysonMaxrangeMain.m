% ----------------------------
% Bryson Maximum-Range Example
% ----------------------------
% This problem is taken verbatim from the following reference:
% Bryson, A. E. and Ho, Y-C, Applied Optimal Control, Hemisphere
% Publishing, New York, 1975.
% ----------------------------
gpopsInitialize;

global constants

constants.gravity = 1;
constants.acc = 0.5*constants.gravity;

x0 = 0;
y0 = 0;
v0 = 0;
yf = 0.1;
xmin = -10;
xmax = -xmin;
ymin = xmin;
ymax = xmax;
vmin = -100;
vmax = -vmin;
u1min = -100;
u1max = -u1min;
u2min = u1min;
u2max = u1max;
t0 = 0;
tf = 2;

iphase = 1;
limits{imin}{iphase,itime} = [t0 tf];
limits{imax}{iphase,itime} = [t0 tf];
limits{imin}{iphase,istate}(1,:) = [x0 xmin xmin];
limits{imax}{iphase,istate}(1,:) = [x0 xmax xmax];
limits{imin}{iphase,istate}(2,:) = [y0 ymin yf];
limits{imax}{iphase,istate}(2,:) = [y0 ymax yf];
limits{imin}{iphase,istate}(3,:) = [v0 vmin vmin];
limits{imax}{iphase,istate}(3,:) = [v0 vmax vmax];
limits{imin}{iphase,icontrol}(1,:) = u1min;
limits{imax}{iphase,icontrol}(1,:) = u1max;
limits{imin}{iphase,icontrol}(2,:) = u2min;
limits{imax}{iphase,icontrol}(2,:) = u2max;
limits{imin}{iphase,iparameter} = []; % No parameters in phase
limits{imax}{iphase,iparameter} = [];
limits{imin}{iphase,ipath} = 1; % One path constraint
limits{imax}{iphase,ipath} = 1;
solinit{iphase,itime} = [t0; tf];
solinit{iphase,istate}(:,1) = [x0; x0];
solinit{iphase,istate}(:,2) = [y0; y0];
solinit{iphase,istate}(:,3) = [v0; v0];
solinit{iphase,icontrol}(:,1) = [1; 1];
solinit{iphase,icontrol}(:,2) = [0; 0];
solinit{iphase,iparameter} = [];

setup.name = 'Bryson-Maxrange';
setup.nodes = 50;
setup.funcs = {'brysonMaxrangeCost','brysonMaxrangeDae',[],[]};
setup.limits = limits;
setup.derivatives = 'complex';
setup.solinit = solinit;
setup.connections = [];
setup.autoscale = 'off';

output = gpops(setup);
solution = output.solution;
