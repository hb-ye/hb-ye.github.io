function [Mayer,Lagrange]=moonlanderCost(solcost,iphase);

t0 = solcost{1,1};
x0 = solcost{1,2};
tf = solcost{1,3};
xf = solcost{1,4};
t  = solcost{2,1};
x  = solcost{2,2};
u  = solcost{2,3};
p  = solcost{2,4};

Mayer = zeros(size(t0));
Lagrange = u;
