clear all
clc

imin = 1; imax = 2;
itime = 1; istate = 2; icontrol = 3; iparameter = 4;
ipath = 5; ievent = 6; iduration = 7;
global CONSTANTS

CONSTANTS.g = 1.6;

h0 = 10;
hf = 0;
v0 = -2;
vf = 0;

hmin = -20;
hmax =  20;
vmin = -20;
vmax =  20;
umin = -10;
umax =  10;
t0min = 0;
t0max = 0;
tfmin = 0;
tfmax = 1000;

% Phase 1 Information
iphase = 1;
limits{imin}{iphase,itime} = [t0min tfmin];
limits{imax}{iphase,itime} = [t0max tfmax];
limits{imin}{iphase,istate}(1,:) = [h0 hmin hf];
limits{imax}{iphase,istate}(1,:) = [h0 hmax hf];
limits{imin}{iphase,istate}(2,:) = [v0 vmin vf];
limits{imax}{iphase,istate}(2,:) = [v0 vmax vf];
limits{imin}{iphase,icontrol} = 0;
limits{imax}{iphase,icontrol} = 3;
limits{imin}{iphase,iparameter} = [];
limits{imax}{iphase,iparameter} = [];
limits{imin}{iphase,ipath} = [];
limits{imax}{iphase,ipath} = [];
limits{imin}{iphase,ievent} = [];
limits{imax}{iphase,ievent} = [];
limits{imin}{iphase,iduration} = [];
limits{imax}{iphase,iduration} = [];
solinit{iphase,itime} = [t0min; tfmax];
solinit{iphase,istate}(:,1) = [h0; h0];
solinit{iphase,istate}(:,2) = [v0; v0];
solinit{iphase,3} = [umin; umin];
solinit{iphase,4} = []; % No parameters in Phase 1

connections = [];
setup.name  = 'Moon-Lander-Problem';
setup.funcs{1} = 'moonlanderCost';
setup.funcs{2} = 'moonlanderDae';
setup.funcs{3} = 'moonlanderEvent';
setup.funcs{4} = 'moonlanderConnect';
setup.nodes = 80;
setup.limits = limits;
setup.solinit = solinit;
setup.connections = connections;
setup.derivatives = 'automatic';
setup.direction = 'increasing';
setup.autoscale = 'off';

output = gpops(setup);
solution = output.solution;
