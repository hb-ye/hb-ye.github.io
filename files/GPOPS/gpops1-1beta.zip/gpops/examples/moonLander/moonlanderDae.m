function daeout = moonlanderDae(soldae,iphase);

global CONSTANTS

t = soldae{1};
x = soldae{2};
u = soldae{3};
p = soldae{4};

h = x(:,1);
v = x(:,2);

hdot = v;
vdot = -CONSTANTS.g+u;

daeout = [hdot vdot];
