% ---------------------------------------------------------------- %
% This script runs all of the exampes in % the GPOPS distribution. %
% This script is  designed for testing to make sure that you have  %
% properly installed GPOPS.                                        %
%------------------------------------------------------------------%
% GPOPS Copyright (c) Anil V. Rao, Geoffrey T. Huntington, David   %
% Benson, Michael Patterson, and Christopher Darby.                %
%------------------------------------------------------------------%

gpopsexamples = pwd;
% Hyper-sensitive problem %
directory{1} = strcat(gpopsexamples,'/brysonDenham/');
wrapperfile{1}  = 'brysonDenhamWrapper';
directory{2} = strcat(gpopsexamples,'/brysonMaxrange/');
wrapperfile{2}  = 'brysonMaxrangeWrapper';
directory{3} = strcat(gpopsexamples,'/chemicalProcess/');
wrapperfile{3}  = 'chemicalProcessWrapper';
directory{4} = strcat(gpopsexamples,'/hyperSensitive/');
wrapperfile{4}  = 'hyperSensitiveWrapper';
directory{5} = strcat(gpopsexamples,'/launch/');
wrapperfile{5}  = 'launchWrapper';
directory{6} = strcat(gpopsexamples,'/linearTangentSteering/');
wrapperfile{6}  = 'linearTangentWrapper';
directory{7} = strcat(gpopsexamples,'/minimumClimb/');
wrapperfile{7}  = 'minimumClimbWrapper';
directory{8} = strcat(gpopsexamples,'/moonLander/');
wrapperfile{8}  = 'moonlanderWrapper';
directory{9} = strcat(gpopsexamples,'/rlvEntry/');
wrapperfile{9}  = 'rlvEntryWrapper';
for i=1:length(directory);
    cd(directory{i});
    clear setup limits
    feval(wrapperfile{i});
    gpopsClean;
end;
cd(gpopsexamples);    
