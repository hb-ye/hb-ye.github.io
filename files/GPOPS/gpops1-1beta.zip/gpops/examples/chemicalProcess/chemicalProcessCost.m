function [Mayer,Lagrange]=moonlanderCost(solcost,iphase);

t0 = solcost{1,1};
s0 = solcost{1,2};
tf = solcost{1,3};
sf = solcost{1,4};
t  = solcost{2,1};
s  = solcost{2,2};
u  = solcost{2,3};
p  = solcost{2,4};

x = s(:,1);
z = s(:,2);

Mayer = zeros(size(t0));
Lagrange = x.^4+0.5.*z.^2+0.5.*u.^2;
