function chemicalProcessWrapper;

chemicalProcessMain;

