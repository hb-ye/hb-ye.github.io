function daeout = moonlanderDae(soldae,iphase);


t = soldae{1};
s = soldae{2};
u = soldae{3};
p = soldae{4};

x = s(:,1);
z = s(:,2);

xdot = x.*z;
zdot = (-z+u).*10;

daeout = [xdot zdot];
