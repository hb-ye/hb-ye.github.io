function minimumClimbWrapper;

minimumClimbMain;

