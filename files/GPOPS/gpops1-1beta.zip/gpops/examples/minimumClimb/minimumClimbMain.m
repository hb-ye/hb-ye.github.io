% Minimum Time-to-Climb Problem 
% The vehicle model for this problem is taken 
% from the following two references:
% Seywald, H., Clifs, E. M., and Well, K. H., 
% "Range Optimal Trajectories for an Aircraft Flying in 
%  the Vertical Plane," Journal of Guidance, Control, and Dynamics,
%  Vol. 17, No. 2, March-April, 1994.
%
%  Rao, A. V., Extension of a Computational Singular Perturbation
%  Methodology to Optimal Control Problems, Ph.D. Thesis, Dept. of
%  Mechanical and Aerospace Engineering, Princeton University,
%  June 1996.

clear all
clc
global CoF;

gpopsInitialize;
g = 9.80665;
m = 37000/2.2;
Coefficients;
feettometer = .3048;

h0 = 0*feettometer;
hf = 65600*feettometer;
v0 = 424.26*feettometer;
vf = 968.148*feettometer;
e0 = (v0^2/(2*g)+h0);
ef = (vf^2/(2*g)+hf);
fpa0 = 0;
fpaf = 0;

hmin =  0*feettometer;
hmax =  69000*feettometer;
vmin =  1*feettometer;
vmax =  2000*feettometer;
emin = (vmin^2/(2*g)+hmin);
emax = (vmax^2/(2*g)+hmax);
fpamin = -40/180*pi;
fpamax = -fpamin;
umin = -10;
umax =  10;
t0min = 0;
t0max = 0;
tfmin = 100;
tfmax = 350;

% Phase 1 Information
iphase = 1;
limits{imin}{iphase,itime} = [t0min tfmin];
limits{imax}{iphase,itime} = [t0max tfmax];
limits{imin}{iphase,istate}(1,:) = [h0 hmin hf];
limits{imax}{iphase,istate}(1,:) = [h0 hmax hf];
limits{imin}{iphase,istate}(2,:) = [e0 emin ef];
limits{imax}{iphase,istate}(2,:) = [e0 emax ef];
limits{imin}{iphase,istate}(3,:) = [fpa0 fpamin fpaf];
limits{imax}{iphase,istate}(3,:) = [fpa0 fpamax fpaf];
limits{imin}{iphase,icontrol} = umin;
limits{imax}{iphase,icontrol} = umax;
limits{imin}{iphase,iparameter} = [];
limits{imax}{iphase,iparameter} = [];
limits{imin}{iphase,ipath} = [];
limits{imax}{iphase,ipath} = [];
limits{imin}{iphase,ievent} = [];
limits{imax}{iphase,ievent} = [];
limits{imin}{iphase,iduration} = [];
limits{imax}{iphase,iduration} = [];
solinit{iphase,itime} = [t0min; tfmax];
solinit{iphase,istate}(:,1) = [hf/2; hf/2];
solinit{iphase,istate}(:,2) = [ef/2; ef/2];
solinit{iphase,istate}(:,3) = [fpamax/2; fpamax/2];
solinit{iphase,3} = [0; 0];
solinit{iphase,4} = []; % No parameters in Phase 1

connections = [];
setup.name  = 'Minimum-Time-to-Climb-Problem';
setup.funcs{1} = 'minimumClimbCost';
setup.funcs{2} = 'minimumClimbDae';
setup.funcs{3} = 'mininumClimbEvent';
setup.funcs{4} = 'minimumClimbConnect';
setup.nodes = 50;
setup.limits = limits;
setup.solinit = solinit;
setup.connections = connections;
setup.derivatives = 'complex';
setup.direction = 'increasing';
setup.autoscale = 'on';

output = gpops(setup);

solution = output.solution;

