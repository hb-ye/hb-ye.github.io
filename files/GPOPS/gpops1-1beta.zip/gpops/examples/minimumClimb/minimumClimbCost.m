function [Mayer,Lagrange]=minimumClimbCost(solcost,iphase);

t0 = solcost{1,1};
s0 = solcost{1,2};
tf = solcost{1,3};
sf = solcost{1,4};
t  = solcost{2,1};
s  = solcost{2,2};
u  = solcost{2,3};
p  = solcost{2,4};


Mayer = tf;
Lagrange = zeros(size(t));
