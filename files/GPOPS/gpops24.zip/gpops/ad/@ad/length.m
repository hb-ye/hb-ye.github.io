function l = length(x);

% AD implementation of length.m
% Code written by Ilyssa Sanders and Anil V. Rao
% January 2009

l = length(x.value);

