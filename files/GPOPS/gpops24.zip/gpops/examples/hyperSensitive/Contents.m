% Contents.m
%
% hyperSensitiveWrapper.m:  The wrapper file for the Hyper-Sensitive Problem
% hyperSensitiveMain.m:     The main file for the Hyper-Sensitive Problem
% hyperSensitiveCost.m:     The cost function file for the Hyper-Sensitive
%                           Problem
% hyperSensitiveDae.m :     The differential algebraic equations file for the
%                           Hyper-Sensitive Problem
