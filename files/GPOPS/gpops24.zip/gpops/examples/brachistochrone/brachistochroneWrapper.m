function brachistochroneWrapper;

brachistochroneMain;
