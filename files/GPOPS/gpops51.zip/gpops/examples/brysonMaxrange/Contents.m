% Contents.m
%
% brysonMaxrangeMain.m:     The main file for the Bryson Max Range Problem
% brysonMaxrangeCost.m:     The cost function file for the Bryson Max Range 
%                           Problem
% brysonMaxrangeDae.m :     The differential algebraic equations file for the
%                           Bryson Max Range Problem
