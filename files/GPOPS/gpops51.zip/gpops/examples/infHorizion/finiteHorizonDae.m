%-------------------------------------
% BEGIN: function finiteHorizonDae.m
%-------------------------------------
function dae = finiteHorizonDae(sol)

% tau = sol.time;
y = sol.state;
u = sol.control;

% dt_dtau = -2*tau./(1-tau).^2;

ydot = y.*log(y) + y.*u;

dae = [ydot];
%-----------------------------------
% END: function finiteHorizonDae.m
%-----------------------------------

