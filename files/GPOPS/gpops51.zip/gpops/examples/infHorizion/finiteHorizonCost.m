%--------------------------------------
% BEGIN: function finiteHorizonCost.m
%--------------------------------------
function [Mayer,Lagrange]=finiteHorizonCost(sol)

% tau  = sol.time;
y = sol.state;
u = sol.control;

% dt_dtau = -2*tau./(1-tau).^2;

Mayer = 0;
Lagrange = 0.5 * ( log(y).^2 + u.^2 );

%--------------------------------------
% END: function finiteHorizonCost.m
%--------------------------------------