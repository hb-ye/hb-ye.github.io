% -----------------------
% infinte Horizon Problem
% -----------------------
% --------------------------------------------------
% This example is a modification of the problem found
% in the following reference:
% --------------------------------------------------
% Garg, D., Patterson, M. A., Hager, W. W., Rao, A. V., 
% "Pseudospectral Methods for Solving Infinite-Horizon 
% Optimal Control Problems," Automatica, Vol. 47, No. 4, 
% April 2011, pp. 829-837. DOI: 10.1016/j.automatica.2011.01.085
%  --------------------------------------------------
% The problem solved here is given as follows:
% Minimize 
%      0.5 * int( ln(y)^2 + u^2 )dt
% subject to the dynamic constraints
%      dy/dt = y * ln(y) + y * u
% with the boundary conditions
%      y(0) = 2
%
%  --------------------------------------------------

clear setup limits guess linkages

y0 = 2;

iphase = 1;

limits(iphase).meshPoints = [-1 +1];
limits(iphase).nodesPerInterval = [10];
limits(iphase).time.min = [-1 1];
limits(iphase).time.max = [-1 1];
limits(iphase).state.min(1,:) = [y0 1 1];
limits(iphase).state.max(1,:) = [y0 10 10];
limits(iphase).control.min    = -100;
limits(iphase).control.max    =  100;
limits(iphase).parameter.min  = [];
limits(iphase).parameter.max  = [];
limits(iphase).path.min       = [];
limits(iphase).path.max       = [];
limits(iphase).event.min      = [];
limits(iphase).event.max      = [];
limits(iphase).duration.min   = [];
limits(iphase).duration.max   = [];

guess(iphase).time            = [-1; 1];
guess(iphase).state           = [y0; 1];
guess(iphase).control         = [0; 0];
guess(iphase).parameter       = [];

setup.name  = 'infHorizon-Problem';
setup.funcs.cost = 'infHorizonCost';
setup.funcs.dae = 'infHorizonDae';
setup.limits = limits;
setup.guess = guess;
setup.linkages = [];
setup.derivatives = 'finite-difference';
setup.autoscale = 'off';
setup.mesh.tolerance = 1e-3;
setup.mesh.iteration = 20;
setup.mesh.nodesPerInterval.min = 4;
setup.mesh.nodesPerInterval.max = 12;

[output] = gpops(setup);
solution = output.solution;
solutionPlot = output.solutionPlot;

tau = solution.time;
t = (1+tau)./(1-tau);

% true solution
x = log(2)*exp(-t*sqrt(2));
y = exp(x);
u = -(1+sqrt(2))*x;
lam = (1+sqrt(2))*exp(-x).*x;

figure('name','state(tau)')
plot(tau,solution.state,'o-');
hold on
plot(tau,y,'r');
grid on
legend('approx','true');

figure('name','control(tau)')
plot(tau,solution.control,'o-');
hold on
plot(tau,u,'r');
grid on
legend('approx','true');

figure('name','costate(tau)')
plot(tau,solution.costate,'o-');
hold on
plot(tau,lam,'r');
grid on
legend('approx','true');

figure('name','state(t)')
plot(t,solution.state,'o-');
hold on
plot(t,y,'r');
grid on
legend('approx','true');

figure('name','control(t)')
plot(t,solution.control,'o-');
hold on
plot(t,u,'r');
grid on
legend('approx','true');

figure('name','costate(t)')
plot(t,solution.costate,'o-');
hold on
plot(t,lam,'r');
grid on
legend('approx','true');

