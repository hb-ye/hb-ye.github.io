function y = nnz(x)

% AD implementation of nnz.m
% Code written by David Benson
% August 2011

y = nnz(x.value);


