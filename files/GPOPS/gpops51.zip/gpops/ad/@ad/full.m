function x = full(x)

% AD implementation of full.m
% Code written by Ilyssa Sanders and Anil V. Rao
% January 2009


x.value = full(x.value);

