function [k,rho] = gpopsCurvature(t,x)
%---------------------------------------------------------%
% This function computes the curvature of the trajectory  %
% stored in the variable x with corresponding time points %
% stored in the variable t.                               %
%---------------------------------------------------------%
tf = t(end);
t0 = t(1);
tstep = (tf-t0)/500;  
tall = [t0:tstep:tf].';
tcent = (tall(2:end)+tall(1:end-1))/2;
xcent = gpopsLagrange(tcent,t,x);
xstep = gpopsLagrange(tall,t,x);
xderiv = (xcent(2:end,:)-xcent(1:end-1,:))/tstep;
xdderiv = (xstep(3:end,:)-2*xstep(2:end-1,:)+xstep(1:end-2,:))/tstep^2;
k = abs(xdderiv)./((1+xderiv.^2).^(1.5));
rho = k.^(1/3);
